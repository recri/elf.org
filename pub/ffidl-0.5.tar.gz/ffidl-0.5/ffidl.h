/* ffidl.h.  Generated automatically by configure.  */
/* ffidl.h.in.  hand written.  */

/* Define the Ffidl version */
#define VERSION "0.5"

/* Define the canonical host */
#define CANONICAL_HOST "i686-pc-linux-gnu"

/* Define if you have the <dlfcn.h> header file.  */
#define HAVE_DLFCN_H 1

/* Define if using the ffcall foreign function library */
/* #undef USE_FFCALL */

/* Define if using the libffi foreign function library */
#define USE_LIBFFI 1

/* Define if you want callbacks */
#define USE_CALLBACKS 1

/* Define if building dlls. */
/* #undef BUILD_Ffidl */

/* Define if building without stubs */
/* #undef STATIC_BUILD */

/* Define if building with threaded Tcl */
/* #undef TCL_THREADS */

/* Define if using tcl stubs interface */
#define USE_TCL_STUBS 1

/* No idea at all where this is coming from */
/* #undef _REENTRANT */

/* Define if your processor stores words with the most significant
   byte first (like Motorola and SPARC, unlike Intel and VAX).  */
/* #undef WORDS_BIGENDIAN */

/* Define if type char is unsigned and you are not using gcc.  */
#ifndef __CHAR_UNSIGNED__
/* #undef __CHAR_UNSIGNED__ */
#endif

/* Define if the 'long long' type works.  */
#define HAVE_LONG_LONG 1

/* Define if the `long double' type works.  */
#define HAVE_LONG_DOUBLE 1

/* The number of bytes in a char.  */
#define SIZEOF_CHAR 1

/* The alignment in struct for a char.  */
#define ALIGNOF_ELT_CHAR 1

/* The number of bytes in a short.  */
#define SIZEOF_SHORT 2

/* The alignment in struct for a short.  */
#define ALIGNOF_ELT_SHORT 2

/* The number of bytes in a int.  */
#define SIZEOF_INT 4

/* The alignment in struct for a int.  */
#define ALIGNOF_ELT_INT 4

/* The number of bytes in a long.  */
#define SIZEOF_LONG 4

/* The alignment in struct for a long.  */
#define ALIGNOF_ELT_LONG 4

/* The number of bytes in a long long.  */
#define SIZEOF_LONG_LONG 8

/* The alignment in struct for a long long.  */
#define ALIGNOF_ELT_LONG_LONG 4

/* The number of bytes in a float.  */
#define SIZEOF_FLOAT 4

/* The alignment in struct for a float.  */
#define ALIGNOF_ELT_FLOAT 4

/* The number of bytes in a double.  */
#define SIZEOF_DOUBLE 8

/* The alignment in struct for a double.  */
#define ALIGNOF_ELT_DOUBLE 4

/* The number of bytes in a double.  */
#define SIZEOF_LONG_DOUBLE 12

/* The alignment in struct for a double.  */
#define ALIGNOF_ELT_LONG_DOUBLE 4

/* The number of bytes in a pointer.  */
#define SIZEOF_VOID_P 4

/* The alignment in struct for a pointer.  */
#define ALIGNOF_ELT_VOID_P 4

