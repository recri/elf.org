/* -----------------------------------------------------------------*-C-*-
   libffi 2.00-beta - Copyright (c) 1996-1999  Cygnus Solutions

   $Id: ffi.h.in,v 1.3 1999/08/08 13:05:12 green Exp $

   Permission is hereby granted, free of charge, to any person obtaining
   a copy of this software and associated documentation files (the
   ``Software''), to deal in the Software without restriction, including
   without limitation the rights to use, copy, modify, merge, publish,
   distribute, sublicense, and/or sell copies of the Software, and to
   permit persons to whom the Software is furnished to do so, subject to
   the following conditions:

   The above copyright notice and this permission notice shall be included
   in all copies or substantial portions of the Software.

   THE SOFTWARE IS PROVIDED ``AS IS'', WITHOUT WARRANTY OF ANY KIND, EXPRESS
   OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
   MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
   IN NO EVENT SHALL CYGNUS SOLUTIONS BE LIABLE FOR ANY CLAIM, DAMAGES OR
   OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
   ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
   OTHER DEALINGS IN THE SOFTWARE.

   ----------------------------------------------------------------------- */

#ifndef LIBFFI_H
#define LIBFFI_H

/* Specify which architecture libffi is configured for. */
#define X86

/* ---- System configuration information --------------------------------- */

#ifdef PACKAGE
#define OLD_PACKAGE PACKAGE
#undef PACKAGE
#endif
#ifdef VERSION
#define OLD_VERSION VERSION
#undef VERSION
#endif

#include <fficonfig.h>

#undef PACKAGE
#undef VERSION

#ifdef OLD_PACKAGE
#define PACKAGE OLD_PACKAGE
#endif
#ifdef OLD_VERSION
#define VERSION OLD_VERSION
#endif

#if !defined(LIBFFI_ASM)
#include <stddef.h>
#if defined(FFI_DEBUG) 
#include <stdio.h>
#endif
#endif

/* ---- Generic type definitions ----------------------------------------- */

#define FLOAT32 float
#define FLOAT64 double
#define FLOAT80 long double

#define UINT8   unsigned char
#define SINT8   signed char

/* find 16 bit int */
#if SIZEOF_SHORT == 2
#define UINT16  unsigned short
#define SINT16  short
#elif SIZEOF_INT == 2
#define UINT16	unsigned int
#define SINT16  int
#elif SIZEOF_LONG == 2
#define UINT16	unsigned long int
#define SINT16  long int
#elif SIZEOF_LONG_LONG == 2
#define UINT16	unsigned long long int
#define SINT16  long long int
#else
#error "no 16 bit integer"
#endif

/* find 32 bit int */
#if SIZEOF_SHORT == 4
#define UINT32  unsigned short
#define SINT32  short
#elif SIZEOF_INT == 4
#define UINT32	unsigned int
#define SINT32  int
#elif SIZEOF_LONG == 4
#define UINT32	unsigned long int
#define SINT32  long int
#elif SIZEOF_LONG_LONG == 4
#define UINT32	unsigned long long int
#define SINT32  long long int
#else
#error "no 32 bit integer"
#endif

/* find 64 bit int */
#if SIZEOF_SHORT == 8
#define UINT64  unsigned short
#define SINT64  short
#elif SIZEOF_INT == 8
#define UINT64	unsigned int
#define SINT64  int
#elif SIZEOF_LONG == 8
#define UINT64	unsigned long int
#define SINT64  long int
#elif SIZEOF_LONG_LONG == 8
#define UINT64	unsigned long long int
#define SINT64  long long int
#else
#error "no 64 bit integer"
#endif

/* ---- Define generic ffi_types ----------------------------------------- */

/* Characters are 8 bit integral types */
#define ffi_type_schar ffi_type_sint8
#define ffi_type_uchar ffi_type_uint8

#if SIZEOF_INT == 2
#define ffi_type_uint ffi_type_uint16
#define ffi_type_sint ffi_type_sint16
#elif SIZEOF_INT == 4
#define ffi_type_uint ffi_type_uint32
#define ffi_type_sint ffi_type_sint32
#elif SIZEOF_INT == 8
#define ffi_type_uint ffi_type_uint64
#define ffi_type_sint ffi_type_sint64
#else
#error "no int type"
#endif

#if SIZEOF_SHORT == 2
#define ffi_type_ushort ffi_type_uint16
#define ffi_type_sshort ffi_type_sint16
#elif SIZEOF_SHORT == 4
#define ffi_type_ushort ffi_type_uint32
#define ffi_type_sshort ffi_type_sint32
#elif SIZEOF_SHORT == 8
#define ffi_type_ushort ffi_type_uint64
#define ffi_type_sshort ffi_type_sint64
#else
#error "no short type"
#endif

#if SIZEOF_LONG == 2
#define ffi_type_ulong ffi_type_uint16
#define ffi_type_slong ffi_type_sint16
#elif SIZEOF_LONG == 4
#define ffi_type_ulong ffi_type_uint32
#define ffi_type_slong ffi_type_sint32
#elif SIZEOF_LONG == 8
#define ffi_type_ulong ffi_type_uint64
#define ffi_type_slong ffi_type_sint64
#else
#error "no long type"
#endif

#if SIZEOF_LONG_LONG == 2
#define ffi_type_ulonglong ffi_type_uint16
#define ffi_type_slonglong ffi_type_sint16
#elif SIZEOF_LONG_LONG == 4
#define ffi_type_ulonglong ffi_type_uint32
#define ffi_type_slonglong ffi_type_sint32
#elif SIZEOF_LONG_LONG == 8
#define ffi_type_ulonglong ffi_type_uint64
#define ffi_type_slonglong ffi_type_sint64
#else
#error "no long long type"
#endif

/* ---- System specific configurations ----------------------------------- */

#ifdef MIPS
#include <ffi_mips.h>
#else
#define SIZEOF_ARG SIZEOF_VOID_P
#endif

#ifndef LIBFFI_ASM

/* ---- Generic type definitions ----------------------------------------- */

#define ALIGN(v, a)  (((((unsigned) (v))-1) | ((a)-1))+1)

typedef enum ffi_abi {

  /* Leave this for debugging purposes */
  FFI_FIRST_ABI = 0,

  /* ---- Sparc -------------------- */
#ifdef SPARC
  FFI_V8,
  FFI_DEFAULT_ABI = FFI_V8,
  FFI_V8PLUS,
  FFI_V9,
#endif

  /* ---- Intel x86 ---------------- */
#ifdef WIN86
#define X86
#endif

#ifdef X86
  FFI_SYSV,
#ifdef WIN86
  FFI_CDECL,
  FFI_STDCALL,
  FFI_DEFAULT_ABI = FFI_CDECL,
#else
  FFI_DEFAULT_ABI = FFI_SYSV,
#endif
#endif

  /* ---- Mips --------------------- */
#ifdef MIPS
  FFI_O32,
  FFI_N32,
  FFI_N64,
#endif

  /* ---- Alpha -------------------- */
#ifdef ALPHA
  FFI_OSF,
  FFI_DEFAULT_ABI = FFI_OSF,
#endif

  /* ---- Motorola m68k ------------ */
#ifdef M68K
  FFI_SYSV,
  FFI_DEFAULT_ABI = FFI_SYSV,
#endif

  /* ---- PowerPC ------------------ */
#ifdef POWERPC
  FFI_SYSV,
  FFI_GCC_SYSV,
  FFI_DEFAULT_ABI = FFI_GCC_SYSV,
#endif

  /* ---- ARM  --------------------- */
#ifdef ARM
  FFI_SYSV,
  FFI_DEFAULT_ABI = FFI_SYSV,
#endif

  /* Leave this for debugging purposes */
  FFI_LAST_ABI

} ffi_abi;

typedef struct _ffi_type
{
  size_t size;
  unsigned short alignment;
  unsigned short type;
  /*@null@*/ struct _ffi_type **elements;
} ffi_type;

/* These are defined in ffi.c */
extern ffi_type ffi_type_void;
extern ffi_type ffi_type_uint8;
extern ffi_type ffi_type_sint8;
extern ffi_type ffi_type_uint16;
extern ffi_type ffi_type_sint16;
extern ffi_type ffi_type_uint32;
extern ffi_type ffi_type_sint32;
extern ffi_type ffi_type_uint64;
extern ffi_type ffi_type_sint64;
extern ffi_type ffi_type_float;
extern ffi_type ffi_type_double;
extern ffi_type ffi_type_longdouble;
extern ffi_type ffi_type_pointer;

/* Characters are 8 bit integral types */
#define ffi_type_schar ffi_type_sint8
#define ffi_type_uchar ffi_type_uint8

typedef enum {
  FFI_OK = 0,
  FFI_BAD_TYPEDEF,
  FFI_BAD_ABI 
} ffi_status;

typedef unsigned FFI_TYPE;

typedef struct {
  ffi_abi abi;
  unsigned nargs;
  /*@dependent@*/ ffi_type **arg_types;
  /*@dependent@*/ ffi_type *rtype;
  unsigned bytes;
  unsigned flags;

#ifdef MIPS
#if _MIPS_SIM == _ABIN32
  unsigned rstruct_flag;
#endif
#endif

} ffi_cif;

/* ---- Definitions for the raw API -------------------------------------- */

#if !FFI_NO_RAW_API

#if SIZEOF_ARG == 4

#define UINT_ARG UINT32
#define SINT_ARG SINT32

#endif

#if SIZEOF_ARG == 8

#define UINT_ARG UINT64
#define SINT_ARG SINT64

#endif

typedef union {
  SINT_ARG sint;
  UINT_ARG uint;
  char     data[SIZEOF_ARG];
  void*    ptr;
} ffi_raw;

void ffi_raw_call (/*@dependent@*/ ffi_cif *cif, 
		   void (*fn)(), 
		   /*@out@*/ void *rvalue, 
		   /*@dependent@*/ ffi_raw *avalue);

void ffi_ptrarray_to_raw (ffi_cif *cif, void **args, ffi_raw *raw);
void ffi_raw_to_ptrarray (ffi_cif *cif, ffi_raw *raw, void **args);
size_t ffi_raw_size (ffi_cif *cif);




#endif /* !FFI_NO_RAW_API */

/* ---- Definitions for closures ----------------------------------------- */

#if defined X86

#define FFI_CLOSURES 1		/* x86 supports closures */
#define FFI_TRAMPOLINE_SIZE 10
#define FFI_NATIVE_RAW_API 1	/* and has native raw api support */

#else 

#define FFI_CLOSURES 0
#define FFI_NATIVE_RAW_API 0

#endif



#if FFI_CLOSURES

typedef struct {
  char tramp[FFI_TRAMPOLINE_SIZE];
  ffi_cif   *cif;
  void     (*fun)(ffi_cif*,void*,void**,void*);
  void      *user_data;
#if defined WIN86
  char ret[3];			/* ret instruction */
#endif
} ffi_closure;

ffi_status
ffi_prep_closure (ffi_closure*,
		  ffi_cif *,
		  void (*fun)(ffi_cif*,void*,void**,void*),
		  void *user_data);

#if !FFI_NO_RAW_API

typedef struct {
  char tramp[FFI_TRAMPOLINE_SIZE];

  ffi_cif   *cif;

#if !FFI_NATIVE_RAW_API

  /* if this is enabled, then a raw closure has the same layout 
     as a regular closure.  We use this to install an intermediate 
     handler to do the transaltion, void** -> ffi_raw*. */

  void     (*translate_args)(ffi_cif*,void*,void**,void*);
  void      *this_closure;

#endif

  void     (*fun)(ffi_cif*,void*,ffi_raw*,void*);
  void      *user_data;
#if defined WIN86
  char ret[3];			/* ret instruction */
#endif
} ffi_raw_closure;

ffi_status
ffi_prep_raw_closure (ffi_raw_closure*,
		      ffi_cif *cif,
		      void (*fun)(ffi_cif*,void*,ffi_raw*,void*),
		      void *user_data);

#endif /* !FFI_NO_RAW_API */
#endif /* FFI_CLOSURES */

/* ---- Public interface definition -------------------------------------- */

ffi_status ffi_prep_cif(/*@out@*/ /*@partial@*/ ffi_cif *cif, 
			ffi_abi abi,
			unsigned int nargs, 
			/*@dependent@*/ /*@out@*/ /*@partial@*/ ffi_type *rtype, 
			/*@dependent@*/ ffi_type **atypes);

void ffi_call(/*@dependent@*/ ffi_cif *cif, 
	      void (*fn)(), 
	      /*@out@*/ void *rvalue, 
	      /*@dependent@*/ void **avalue);

/* Useful for eliminating compiler warnings */
#define FFI_FN(f) ((void (*)())f)

/* ---- Definitions shared with assembly code ---------------------------- */

#endif

#define FFI_TYPE_VOID       0    
#define FFI_TYPE_INT        1
#define FFI_TYPE_FLOAT      2    
#define FFI_TYPE_DOUBLE     3
#if SIZEOF_LONG_DOUBLE == SIZEOF_DOUBLE
#define FFI_TYPE_LONGDOUBLE FFI_TYPE_DOUBLE
#else
#define FFI_TYPE_LONGDOUBLE 4
#endif

#define FFI_TYPE_UINT8      5   /* If this changes, update ffi_mips.h. */
#define FFI_TYPE_SINT8      6   /* If this changes, update ffi_mips.h. */
#define FFI_TYPE_UINT16     7 
#define FFI_TYPE_SINT16     8
#define FFI_TYPE_UINT32     9
#define FFI_TYPE_SINT32     10
#define FFI_TYPE_UINT64     11
#define FFI_TYPE_SINT64     12
#define FFI_TYPE_STRUCT     13  /* If this changes, update ffi_mips.h. */
#define FFI_TYPE_POINTER    14

/* This should always refer to the last type code (for sanity checks) */
#define FFI_TYPE_LAST       FFI_TYPE_POINTER

#endif

