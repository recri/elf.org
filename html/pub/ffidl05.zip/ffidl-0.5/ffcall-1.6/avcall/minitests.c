#define SKIP_STRUCTS
#include "tests.c"
