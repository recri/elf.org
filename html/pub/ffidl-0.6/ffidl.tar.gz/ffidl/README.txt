------------------------------------------------------------------------
                         Ffidl Version 0.6
    Copyright (c) 1999 by Roger E Critchlow Jr, Santa Fe, NM, USA
                           rec@elf.org

Changes since ffidl 0.5 are under BSD License and are
    Copyright (c) 2005, Daniel A. Steffen <das@users.sourceforge.net>

------------------------------------------------------------------------

Ffidl allows you to define Tcl/Tk extensions with pure Tcl wrappers
calling any shared library installed on your system, including the Tcl
and Tk core libraries.

Documentation can be found at doc/ffidl.html.

license.terms specifies the license under which Ffidl is distributed, and
that there is NO WARRANTY.

lib-src/libffi/LICENSE specifies the license under which libffi is
distributed, and that there is NO WARRANTY.

lib-src/ffcall/COPYING specifies the license under which ffcal is
distributed, and that there is NO WARRANTY.

------------------------------------------------------------------------
