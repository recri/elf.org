/* Define this if you want extra debugging */
#undef FFI_DEBUG

/* Define this if you are using Purify and want to suppress 
   spurious messages. */
#undef USING_PURIFY

/* This is the package name */
#undef PACKAGE

/* This is the package version */
#undef VERSION

