/*****************************************
 * ffidl
 *
 * A combination of libffi, for foreign function interface,
 * and libdl, for dynamic library loading and symbol listing,
 * packaged with hints from ::dll, and exported to Tcl.
 *
 * Ffidl - Copyright (c) 1999 by Roger E Critchlow Jr, Santa Fe, NM, USA
 * 
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the ``Software''), to deal in the Software without
 * restriction, including without limitation the rights to use, copy,
 * modify, merge, publish, distribute, sublicense, and/or sell copies
 * of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED ``AS IS'', WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT.  IN NO EVENT SHALL ROGER E CRITCHLOW JR BE LIABLE
 * FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
 * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

#include <tcl.h>
/*
 * This choice of macro name, ie VERSION, 
 * conflicts with one defined in ffi.h
 */
char Ffidl_VERSION[] = VERSION;
#undef VERSION

/*
 * Windows needs to know which symbols to export.  Unix does not.
 * BUILD_Ffidl should be undefined for Unix.
 */

#ifdef BUILD_Ffidl
#undef TCL_STORAGE_CLASS
#define TCL_STORAGE_CLASS DLLEXPORT
#endif /* BUILD_Ffidl */

#include <string.h>
#include <stdlib.h>

#include <ffi.h>
#include <dlfcn.h>

/*
 * In some systems, like SunOS 4.1.3, the RTLD_NOW flag isn't defined
 * and this argument to dlopen must always be 1.  The RTLD_GLOBAL
 * flag is needed on some systems (e.g. SCO and UnixWare) but doesn't
 * exist on others;  if it doesn't exist, set it to 0 so it has no effect.
 */

#ifndef RTLD_NOW
#   define RTLD_NOW 1
#endif

#ifndef RTLD_GLOBAL
#   define RTLD_GLOBAL 0
#endif

/*****************************************
 *				  
 * Functions exported from this file.
 */
EXTERN void *   ffidl_pointer_pun _ANSI_ARGS_((void *p));
EXTERN int	Ffidl_Init _ANSI_ARGS_((Tcl_Interp * interp));

/*****************************************
 *
 * Definitions.
 */
/*
 * values for ffidl_type.t
 */
#define FFIDL_VOID		0
#define FFIDL_INT		1
#define FFIDL_FLOAT		2
#define FFIDL_DOUBLE		3
#define FFIDL_LONGDOUBLE	4
#define FFIDL_UINT8		5
#define FFIDL_SINT8		6
#define FFIDL_UINT16		7
#define FFIDL_SINT16		8
#define FFIDL_UINT32		9
#define FFIDL_SINT32		10
#define FFIDL_UINT64		11
#define FFIDL_SINT64		12
#define FFIDL_STRUCT		13
#define FFIDL_PTR		14	/* integer value pointer */
#define FFIDL_PTR_BYTE		15	/* byte array pointer */
#define FFIDL_PTR_UTF8		16	/* UTF-8 string pointer */
#define FFIDL_PTR_UTF16		17	/* UTF-16 string pointer */
#define FFIDL_PTR_VAR		18	/* byte array in variable */
#define FFIDL_PTR_OBJ		19	/* Tcl_Obj pointer */
/*
 * aliases for unsized type names
 */
#define FFIDL_SCHAR	FFIDL_SINT8
#define FFIDL_UCHAR	FFIDL_UINT8

#if SIZEOF_SHORT == 2
#define FFIDL_USHORT	FFIDL_UINT16
#define FFIDL_SSHORT	FFIDL_SINT16
#elif SIZEOF_SHORT == 4
#define FFIDL_USHORT	FFIDL_UINT32
#define FFIDL_SSHORT	FFIDL_SINT32
#elif SIZEOF_SHORT == 8
#define FFIDL_USHORT	FFIDL_UINT64
#define FFIDL_SSHORT	FFIDL_SINT64
#else
#error "no short type"
#endif

#if SIZEOF_INT == 2
#define FFIDL_UINT	FFIDL_UINT16
#define FFIDL_SINT	FFIDL_SINT16
#elif SIZEOF_INT == 4
#define FFIDL_UINT	FFIDL_UINT32
#define FFIDL_SINT	FFIDL_SINT32
#elif SIZEOF_INT == 8
#define FFIDL_UINT	FFIDL_UINT64
#define FFIDL_SINT	FFIDL_SINT64
#else
#error "no int type"
#endif

#if SIZEOF_LONG == 2
#define FFIDL_ULONG	FFIDL_UINT16
#define FFIDL_SLONG	FFIDL_SINT16
#elif SIZEOF_LONG == 4
#define FFIDL_ULONG	FFIDL_UINT32
#define FFIDL_SLONG	FFIDL_SINT32
#elif SIZEOF_LONG == 8
#define FFIDL_ULONG	FFIDL_UINT64
#define FFIDL_SLONG	FFIDL_SINT64
#else
#error "no long type"
#endif

#if SIZEOF_LONG_LONG == 2
#define FFIDL_ULONGLONG	FFIDL_UINT16
#define FFIDL_SLONGLONG	FFIDL_SINT16
#elif SIZEOF_LONG_LONG == 4
#define FFIDL_ULONGLONG	FFIDL_UINT32
#define FFIDL_SLONGLONG	FFIDL_SINT32
#elif SIZEOF_LONG_LONG == 8
#define FFIDL_ULONGLONG	FFIDL_UINT64
#define FFIDL_SLONGLONG	FFIDL_SINT64
#else
#error "no long long type"
#endif

/*
 * values for ffidl_type.c
 */
#define FFIDL_ARG		1	/* type parser in argument context */
#define FFIDL_RET		2	/* type parser in return context */
#define FFIDL_ELT		4	/* type parser in element context */
#define FFIDL_ALL		(FFIDL_ARG|FFIDL_RET|FFIDL_ELT)
#define FFIDL_ARGRET		(FFIDL_ARG|FFIDL_RET)
#define FFIDL_GETINT		8	/* arg needs an int value */
#define FFIDL_GETDOUBLE		16	/* arg needs a double value */

/*****************************************
 *
 * Type definitions for ffidl.
 */
/*
 * The ffidl_value structure contains a union used
 * for converting to/from Tcl type.
 */
typedef union {
  int v_int;
  float v_float;
  double v_double;
  long double v_longdouble;
  UINT8 v_uint8;
  SINT8 v_sint8;
  UINT16 v_uint16;
  SINT16 v_sint16;
  UINT32 v_uint32;
  SINT32 v_sint32;
  UINT64 v_uint64;
  SINT64 v_sint64;
  void *v_struct;
  void *v_pointer;
} ffidl_value;

/*
 * The ffidl_type structure contains the underlying ffi_type
 * the ffidl pointer variation, and flags indicating the
 * allowed parse contexts for this type.
 */
typedef struct {
  ffi_type *type;
  unsigned t;
  unsigned c;
} ffidl_type;
/*
 * The ffidl_client contains a hashtable for ffidl-typedef
 * definitions, a hashtable for ffidl-proc definitions, a hashtable
 * for cif's keyed by signature, and a hashtable of libs.
 */
typedef struct {
  Tcl_HashTable types;
  Tcl_HashTable cifs;
  Tcl_HashTable procs;
  Tcl_HashTable libs;
} ffidl_client;

/*
 * The ffidl_cif structure contains an ffi_cif,
 * an array of ffidl_types used to construct the
 * cif and convert arguments, and an array of void*
 * used to pass converted arguments into ffi_call.
 */
typedef struct {
  ffi_cif cif;
  int refs;
  ffidl_client *client;
  ffidl_type *rtype;
  ffidl_value rvalue;
  void *ret;
  ffidl_type **atypes;
  ffidl_value *avalues;
  void **args;
} ffidl_cif;

/*
 * The ffidl_proc contains a cif pointer,
 * a function address, and the ffidl_client
 * which defined the proc.
 */
typedef struct {
  ffidl_cif *cif;
  void (*fn)();
  ffidl_client *client;
  char usage[1];
} ffidl_proc;

/*****************************************
 *
 * Data defined in this file.
 */

int ffidl_little_endian = 0;
Tcl_ObjType *ffidl_bytearray_ObjType;
Tcl_ObjType *ffidl_int_ObjType;
Tcl_ObjType *ffidl_double_ObjType;

/*
 * base types, the ffi base types and some additional bits.
 */
static ffidl_type ffidl_type_void = { &ffi_type_void, FFIDL_VOID, FFIDL_RET };
static ffidl_type ffidl_type_schar = { &ffi_type_schar, FFIDL_SCHAR, FFIDL_ALL|FFIDL_GETINT };
static ffidl_type ffidl_type_uchar = { &ffi_type_uchar, FFIDL_UCHAR, FFIDL_ALL|FFIDL_GETINT };
static ffidl_type ffidl_type_sshort = { &ffi_type_sshort, FFIDL_SSHORT, FFIDL_ALL|FFIDL_GETINT };
static ffidl_type ffidl_type_ushort = { &ffi_type_ushort, FFIDL_USHORT, FFIDL_ALL|FFIDL_GETINT };
static ffidl_type ffidl_type_sint = { &ffi_type_sint, FFIDL_SINT, FFIDL_ALL|FFIDL_GETINT };
static ffidl_type ffidl_type_uint = { &ffi_type_uint, FFIDL_UINT, FFIDL_ALL|FFIDL_GETINT };
static ffidl_type ffidl_type_slong = { &ffi_type_slong, FFIDL_SLONG, FFIDL_ALL|FFIDL_GETINT };
static ffidl_type ffidl_type_ulong = { &ffi_type_ulong, FFIDL_ULONG, FFIDL_ALL|FFIDL_GETINT };
static ffidl_type ffidl_type_slonglong = { &ffi_type_slonglong, FFIDL_SLONGLONG, FFIDL_ALL|FFIDL_GETINT };
static ffidl_type ffidl_type_ulonglong = { &ffi_type_ulonglong, FFIDL_ULONGLONG, FFIDL_ALL|FFIDL_GETINT };
static ffidl_type ffidl_type_float = { &ffi_type_float, FFIDL_FLOAT, FFIDL_ALL|FFIDL_GETDOUBLE };
static ffidl_type ffidl_type_double = { &ffi_type_double, FFIDL_DOUBLE, FFIDL_ALL|FFIDL_GETDOUBLE };
static ffidl_type ffidl_type_longdouble = { &ffi_type_longdouble, FFIDL_LONGDOUBLE, FFIDL_ALL|FFIDL_GETDOUBLE };
static ffidl_type ffidl_type_sint8 = { &ffi_type_sint8, FFIDL_SINT8, FFIDL_ALL|FFIDL_GETINT };
static ffidl_type ffidl_type_uint8 = { &ffi_type_uint8, FFIDL_UINT8, FFIDL_ALL|FFIDL_GETINT };
static ffidl_type ffidl_type_sint16 = { &ffi_type_sint16, FFIDL_SINT16, FFIDL_ALL|FFIDL_GETINT };
static ffidl_type ffidl_type_uint16 = { &ffi_type_uint16, FFIDL_UINT16, FFIDL_ALL|FFIDL_GETINT };
static ffidl_type ffidl_type_sint32 = { &ffi_type_sint32, FFIDL_SINT32, FFIDL_ALL|FFIDL_GETINT };
static ffidl_type ffidl_type_uint32 = { &ffi_type_uint32, FFIDL_UINT32, FFIDL_ALL|FFIDL_GETINT };
static ffidl_type ffidl_type_sint64 = { &ffi_type_sint64, FFIDL_SINT64, FFIDL_ALL|FFIDL_GETINT };
static ffidl_type ffidl_type_uint64 = { &ffi_type_uint64, FFIDL_UINT64, FFIDL_ALL|FFIDL_GETINT };
static ffidl_type ffidl_type_pointer = { &ffi_type_pointer, FFIDL_PTR, FFIDL_ALL|FFIDL_GETINT };
static ffidl_type ffidl_type_pointer_obj = { &ffi_type_pointer, FFIDL_PTR_OBJ, FFIDL_ARGRET };
static ffidl_type ffidl_type_pointer_utf8 = { &ffi_type_pointer, FFIDL_PTR_UTF8, FFIDL_ARGRET };
static ffidl_type ffidl_type_pointer_utf16 = { &ffi_type_pointer, FFIDL_PTR_UTF16, FFIDL_ARGRET };
static ffidl_type ffidl_type_pointer_byte = { &ffi_type_pointer, FFIDL_PTR_BYTE, FFIDL_ARG };
static ffidl_type ffidl_type_pointer_var = { &ffi_type_pointer, FFIDL_PTR_VAR, FFIDL_ARG };

/*****************************************
 *
 * Functions defined in this file.
 */
/* define a hashtable entry */
static void entry_define(Tcl_HashTable *table, char *name, void *datum)
{
  int dummy;
  Tcl_SetHashValue(Tcl_CreateHashEntry(table,name,&dummy), datum);
}
/* lookup an existing entry */
static void *entry_lookup(Tcl_HashTable *table, char *name)
{
  Tcl_HashEntry *entry = Tcl_FindHashEntry(table,name);
  return entry ? Tcl_GetHashValue(entry) : NULL;
}
/* find an entry by it's hash value */
static Tcl_HashEntry *entry_find(Tcl_HashTable *table, void *datum)
{
  Tcl_HashSearch search;
  Tcl_HashEntry *entry = Tcl_FirstHashEntry(table, &search);
  while (entry != NULL) {
    if (Tcl_GetHashValue(entry) == datum)
      return entry;
    entry = Tcl_NextHashEntry(&search);
  }
  return NULL;
}
/* define a new type */
static void type_define(ffidl_client *client, char *tname, ffidl_type *ttype)
{
  entry_define(&client->types,tname,(void*)ttype);
}
/* lookup an existing type */
static ffidl_type *type_lookup(ffidl_client *client, char *tname)
{
  return entry_lookup(&client->types,tname);
}
/* find a type by it's ffidl_type */
static Tcl_HashEntry *type_find(ffidl_client *client, ffidl_type *type)
{
  return entry_find(&client->types,(void *)type);
}
/* parse an argument or return type specification */
static int type_parse(Tcl_Interp *interp, ffidl_client *client, unsigned context, Tcl_Obj *obj,
		      ffi_type **type0, ffidl_type **type1, ffidl_value *type2, void **argp)
{
  char *arg = Tcl_GetString(obj);
  char buff[128];

  /* lookup the type */
  *type1 = type_lookup(client, arg);
  if (*type1 == NULL) {
    Tcl_AppendResult(interp, "no type defined for: ", arg, NULL);
   return TCL_ERROR;
  }
  /* test the context */
  if ((context & (*type1)->c) == 0) {
    Tcl_AppendResult(interp, "type ", arg, " is not permitted in ",
		     (context&FFIDL_ARG) ? "argument" :  "return",
		     " context.", NULL);
    return TCL_ERROR;
  }
  /* set the ffi_type */
  *type0 = (*type1)->type;
  /* set arg value pointer */
  switch ((*type1)->t) {
  case FFIDL_VOID:		break;
  case FFIDL_INT:		*argp = (void *)&type2->v_int; break;
  case FFIDL_FLOAT:		*argp = (void *)&type2->v_float; break;
  case FFIDL_DOUBLE:		*argp = (void *)&type2->v_double; break;
  case FFIDL_LONGDOUBLE:	*argp = (void *)&type2->v_longdouble; break;
  case FFIDL_UINT8:		*argp = (void *)&type2->v_uint8; break;
  case FFIDL_SINT8:		*argp = (void *)&type2->v_sint8; break;
  case FFIDL_UINT16:		*argp = (void *)&type2->v_uint16; break;
  case FFIDL_SINT16:		*argp = (void *)&type2->v_sint16; break;
  case FFIDL_UINT32:		*argp = (void *)&type2->v_uint32; break;
  case FFIDL_SINT32:		*argp = (void *)&type2->v_sint32; break;
  case FFIDL_UINT64:		*argp = (void *)&type2->v_uint64; break;
  case FFIDL_SINT64:		*argp = (void *)&type2->v_sint64; break;
  case FFIDL_PTR:		*argp = (void *)&type2->v_pointer; break;
  case FFIDL_PTR_BYTE:		*argp = (void *)&type2->v_pointer; break;
  case FFIDL_PTR_OBJ:		*argp = (void *)&type2->v_pointer; break;
  case FFIDL_PTR_UTF8:		*argp = (void *)&type2->v_pointer; break;
  case FFIDL_PTR_UTF16:		*argp = (void *)&type2->v_pointer; break;
  case FFIDL_PTR_VAR:		*argp = (void *)&type2->v_pointer; break;
  case FFIDL_STRUCT:		*argp = (void *)&type2->v_struct; break;
  default:
    sprintf(buff, "unknown ffi_type.type = %d", (*type1)->type->type);
    Tcl_AppendResult(interp, buff, NULL);
    return TCL_ERROR;
  }
  return TCL_OK;
}
/* build a binary format string */
static int type_format(Tcl_Interp *interp, ffi_type *type, int *offset)
{
  int i;
  char buff[128];
  /* Insert alignment padding */
  while ((*offset % type->alignment) != 0) {
    Tcl_AppendResult(interp, "x", NULL);
    *offset += 1;
  }
  switch (type->type) {
  case FFI_TYPE_INT:
  case FFI_TYPE_UINT8:
  case FFI_TYPE_SINT8:
  case FFI_TYPE_UINT16:
  case FFI_TYPE_SINT16:
  case FFI_TYPE_UINT32:
  case FFI_TYPE_SINT32:
  case FFI_TYPE_UINT64:
  case FFI_TYPE_SINT64:
  case FFI_TYPE_POINTER:
    if (type->size == sizeof(int)) {
      *offset += 4;
      Tcl_AppendResult(interp, ffidl_little_endian ? "i" : "I", NULL);
      return TCL_OK;
    } else if (type->size == sizeof(short)) {
      *offset += 2;
      Tcl_AppendResult(interp, ffidl_little_endian ? "s" : "S", NULL);
      return TCL_OK;
    } else if (type->size == sizeof(char)) {
      *offset += 1;
      Tcl_AppendResult(interp, "c", NULL);
      return TCL_OK;
    } else {
      *offset += type->size;
      sprintf(buff, "c%d", type->size);
      Tcl_AppendResult(interp, buff, NULL);
      return TCL_OK;
    }
  case FFI_TYPE_FLOAT:
  case FFI_TYPE_DOUBLE:
#if FFI_TYPE_LONGDOUBLE != FFI_TYPE_DOUBLE
  case FFI_TYPE_LONGDOUBLE:
#endif
    if (type->size == sizeof(double)) {
      *offset += 8;
      Tcl_AppendResult(interp, "d", NULL);
      return TCL_OK;
    } else if (type->size == sizeof(float)) {
      *offset += 4;
      Tcl_AppendResult(interp, "f", NULL);
      return TCL_OK;
    } else {
      *offset += type->size;
      sprintf(buff, "c%d", type->size);
      Tcl_AppendResult(interp, buff, NULL);
      return TCL_OK;
    }
  case FFI_TYPE_STRUCT:
    for (i = 0; type->elements[i] != NULL; i += 1)
      if (type_format(interp, type->elements[i], offset) != TCL_OK)
	return TCL_ERROR;
    return TCL_OK;
  default:
    sprintf(buff, "cannot format ffi_type: %d", type->type);
    Tcl_ResetResult(interp);
    Tcl_AppendResult(interp, buff, NULL);
    return TCL_ERROR;
  }
}
/* define a new cif */
static void cif_define(ffidl_client *client, char *cname, ffidl_cif *cif)
{
  entry_define(&client->cifs,cname,(void*)cif);
}
/* lookup an existing cif */
static ffidl_cif *cif_lookup(ffidl_client *client, char *cname)
{
  return entry_lookup(&client->cifs,cname);
}
/* find a cif by it's ffidl_cif */
static Tcl_HashEntry *cif_find(ffidl_client *client, ffidl_cif *cif)
{
  return entry_find(&client->cifs,(void *)cif);
}
/* maintain reference counts on cif's */
static void cif_inc_ref(ffidl_cif *cif) {
  cif->refs += 1;
}
static void cif_dec_ref(ffidl_cif *cif) {
  if (--cif->refs == 0) {
    Tcl_DeleteHashEntry(cif_find(cif->client, cif));
    ckfree((void *)cif);
  }
}
/* define a new proc */
static void proc_define(ffidl_client *client, char *pname, ffidl_proc *proc)
{
  entry_define(&client->procs,pname,(void*)proc);
}
/* lookup an existing proc */
static ffidl_proc *proc_lookup(ffidl_client *client, char *pname)
{
  return entry_lookup(&client->procs,pname);
}
/* find a proc by it's ffidl_proc */
static Tcl_HashEntry *proc_find(ffidl_client *client, ffidl_proc *proc)
{
  return entry_find(&client->procs,(void *)proc);
}
/* cleanup on ffidl_proc_call deletion */
static void proc_delete(ClientData clientData)
{
  ffidl_proc *proc = (ffidl_proc *)clientData;
  Tcl_HashEntry *entry = proc_find(proc->client, proc);
  if (entry) {
    cif_dec_ref(proc->cif);
    ckfree((void *)proc);
    Tcl_DeleteHashEntry(entry);
  }
}
/* define a new lib */
static void lib_define(ffidl_client *client, char *lname, void *handle)
{
  entry_define(&client->libs,lname,handle);
}
/* lookup an existing type */
static void *lib_lookup(ffidl_client *client, char *lname)
{
  return entry_lookup(&client->libs,lname);
}

/*****************************************
 *
 * Functions exported as tcl commands.
 */

/* usage: ffidl-info option ?...? -> information */
static int tcl_ffidl_info(ClientData clientData, Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[])
{
  int i;
  char *arg;
  Tcl_HashTable *table;
  Tcl_HashSearch search;
  Tcl_HashEntry *entry;
  ffidl_type *type;
  ffidl_client *client = (ffidl_client *)clientData;
  static char *options[] = {
    "alignof",
#define INFO_ALIGNOF 0
    "format",
#define INFO_FORMAT 1
    "interp",
#define INFO_INTERP 2
    "libraries",
#define INFO_LIBRARIES 3
    "procs",
#define INFO_PROCS 4
    "signatures",
#define INFO_SIGNATURES 5
    "sizeof",
#define INFO_SIZEOF 6
    "typedefs",
#define INFO_TYPEDEFS 7
    NULL
  };

  if (objc < 2) {
    Tcl_WrongNumArgs(interp, 1, objv, "option ?arg ...?");
    return TCL_ERROR;
  }

  if (Tcl_GetIndexFromObj(interp, objv[1], options, "option", TCL_EXACT, &i) == TCL_ERROR)
    return TCL_ERROR;

  switch (i) {
  case INFO_PROCS:		/* return list of proc names */
    table = &client->procs;
  list_table_keys:
    if (objc != 2) {
      Tcl_WrongNumArgs(interp,2,objv,"");
      return TCL_ERROR;
    }
    for (entry = Tcl_FirstHashEntry(table, &search); entry != NULL; entry = Tcl_NextHashEntry(&search))
      Tcl_ListObjAppendElement(interp, Tcl_GetObjResult(interp), Tcl_NewStringObj(Tcl_GetHashKey(table,entry),-1));
    return TCL_OK;
  case INFO_TYPEDEFS:		/* return list of typedef names */
    table = &client->types;
    goto list_table_keys;
  case INFO_SIGNATURES:		/* return list of ffi signatures */
    table = &client->cifs;
    goto list_table_keys;
  case INFO_LIBRARIES:		/* return list of lib names */
    table = &client->libs;
    goto list_table_keys;
  case INFO_SIZEOF:		/* return sizeof type */
  case INFO_ALIGNOF:		/* return alignof type */
  case INFO_FORMAT:		/* return binary format of type */
    if (objc != 3) {
      Tcl_WrongNumArgs(interp,2,objv,"type");
      return TCL_ERROR;
    }
    arg = Tcl_GetString(objv[2]);
    type = type_lookup(client, arg);
    if (type == NULL) {
      Tcl_AppendResult(interp, "undefined type: ", arg, NULL);
      return TCL_ERROR;
    }
    if (i == INFO_SIZEOF) {
      if (type->type->type == FFI_TYPE_VOID)
	Tcl_SetObjResult(interp, Tcl_NewIntObj(0));
      else
	Tcl_SetObjResult(interp, Tcl_NewIntObj(type->type->size));
      return TCL_OK;
    }
    if (i == INFO_ALIGNOF) {
      Tcl_SetObjResult(interp, Tcl_NewIntObj(type->type->alignment));
      return TCL_OK;
    }
    if (i == INFO_FORMAT) {
      i = 0;
      return type_format(interp, type->type, &i);
    }
    Tcl_AppendResult(interp, "lost?", NULL);
  case INFO_INTERP:
    /* return the interp as integer */
    if (objc != 2) {
      Tcl_WrongNumArgs(interp,2,objv,"");
      return TCL_ERROR;
    }
    Tcl_SetObjResult(interp, Tcl_NewIntObj((int)interp));
    return TCL_OK;
  }
  
  /* return an error */
  Tcl_AppendResult(interp, "missing option implementation: ", Tcl_GetString(objv[1]), NULL);
  return TCL_ERROR;
}

/* usage: ffidl-typedef name type1 ?type2 ...? */
static int tcl_ffidl_typedef(ClientData clientData, Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[])
{
  char *tname1, *tname2;
  ffidl_type *newtype, *ttype2;
  int nelt, i;
  ffidl_client *client = (ffidl_client *)clientData;
  /* check number of args */
  if (objc < 3) {
    Tcl_WrongNumArgs(interp,1,objv,"name type ?...?");
    return TCL_ERROR;
  }
  /* fetch new type name, verify that it is new */
  tname1 = Tcl_GetString(objv[1]);
  if (type_lookup(client, tname1) != NULL) {
    Tcl_AppendResult(interp, "type is already defined: ", tname1, NULL);
    return TCL_ERROR;
  }
  /* define tname1 as an alias for tname2 */
  if (objc == 3) {
    tname2 = Tcl_GetString(objv[2]);
    ttype2 = type_lookup(client, tname2);
    if (ttype2 == NULL) {
      Tcl_AppendResult(interp, "undefined type: ", tname2, NULL);
      return TCL_ERROR;
    }
    type_define(client, tname1, ttype2);
    return TCL_OK;
  }
  /* allocate an aggregate type */
  nelt = objc-2;
  newtype = (ffidl_type *)ckalloc(sizeof(ffidl_type)+sizeof(ffi_type)+(nelt+1)*sizeof(ffi_type *));
  if (newtype == NULL) {
    Tcl_AppendResult(interp, "couldn't allocate the ffi_type", NULL); 
    return TCL_ERROR;
  }
  /* initialize aggregate type */
  newtype->type = (ffi_type *)(newtype+1);
  newtype->type->size = 0;
  newtype->type->alignment = 0;
  newtype->type->type = FFI_TYPE_STRUCT;
  newtype->type->elements = (ffi_type **)(newtype->type+1);
  newtype->t = FFIDL_STRUCT;
  newtype->c = FFIDL_ALL;
  /* parse aggregate types */
  for (i = 0; i < nelt; i += 1) {
    tname2 = Tcl_GetString(objv[2+i]);
    ttype2 = type_lookup(client, tname2);
    if (ttype2 == NULL) {
      ckfree((void *)newtype);
      Tcl_AppendResult(interp, "undefined element type: ", tname2, NULL);
      return TCL_ERROR;
    }
    if ((ttype2->c & FFIDL_ELT) == 0) {
      ckfree((void *)newtype);
      Tcl_AppendResult(interp, "type ", tname2, " is not permitted in element context", NULL);
      return TCL_ERROR;
    }
    newtype->type->elements[i] = ttype2->type;
  }
  newtype->type->elements[nelt] = NULL;
  /* try out new type in a temporary cif, which should set size and alignment */
  {
    ffi_cif cif;
    if (ffi_prep_cif(&cif, FFI_DEFAULT_ABI, 0, newtype->type, NULL) != FFI_OK) {
      ckfree((void *)newtype);
      Tcl_AppendResult(interp, "type definition error", NULL);
      return TCL_ERROR;
    }
  }
  /* define new type */
  type_define(client, tname1, newtype);
  /* return success */
  return TCL_OK;
}

/* usage: depends on the signature defining the ffidl-proc */
static int tcl_ffidl_call(ClientData clientData, Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[])
{
  ffidl_proc *proc = (ffidl_proc *)clientData;
  ffidl_cif *cif = proc->cif;
  int i, itmp;
  long ltmp;
  double dtmp;
  Tcl_Obj *obj;
  char buff[128];
  /* usage check */
  if (objc-1 != cif->cif.nargs) {
    Tcl_WrongNumArgs(interp, 1, objv, proc->usage);
    return TCL_ERROR;
  }
  /* fetch and convert argument values */
  for (i = 0; i < cif->cif.nargs; i += 1) {
    /* fetch object */
    obj = objv[1+i];
    /* fetch value from object and store value into arg value array */
    if (cif->atypes[i]->c & FFIDL_GETINT) {
      if (obj->typePtr == ffidl_double_ObjType) {
	if (Tcl_GetDoubleFromObj(interp, obj, &dtmp) == TCL_ERROR)
	  return TCL_ERROR;
	ltmp = (int)dtmp;
	if (dtmp != ltmp)
	  if (Tcl_GetLongFromObj(interp, obj, &ltmp) == TCL_ERROR)
	    return TCL_ERROR;
      } else if (Tcl_GetLongFromObj(interp, obj, &ltmp) == TCL_ERROR)
	return TCL_ERROR;
    } else if (cif->atypes[i]->c & FFIDL_GETDOUBLE) {
      if (obj->typePtr == ffidl_int_ObjType) {
	if (Tcl_GetLongFromObj(interp, obj, &ltmp) == TCL_ERROR)
	  return TCL_ERROR;
	dtmp = (double)ltmp;
	if (dtmp != ltmp)
	  if (Tcl_GetDoubleFromObj(interp, obj, &dtmp) == TCL_ERROR)
	    return TCL_ERROR;
      } else if (Tcl_GetDoubleFromObj(interp, obj, &dtmp) == TCL_ERROR)
	return TCL_ERROR;
    }
    switch (cif->atypes[i]->t) {
    case FFIDL_INT:
      cif->avalues[i].v_int = ltmp;
      continue;
    case FFIDL_FLOAT:
      cif->avalues[i].v_float = dtmp;
      continue;
    case FFIDL_DOUBLE:
      cif->avalues[i].v_double = dtmp;
      continue;
    case FFIDL_LONGDOUBLE:
      cif->avalues[i].v_longdouble = dtmp;
      continue;
    case FFIDL_UINT8:
      cif->avalues[i].v_uint8 = ltmp;
      continue;
    case FFIDL_SINT8:
      cif->avalues[i].v_sint8 = ltmp;
      continue;
    case FFIDL_UINT16:
      cif->avalues[i].v_uint16 = ltmp;
      continue;
    case FFIDL_SINT16:
      cif->avalues[i].v_sint16 = ltmp;
      continue;
    case FFIDL_UINT32:
      cif->avalues[i].v_uint32 = ltmp;
      continue;
    case FFIDL_SINT32:
      cif->avalues[i].v_sint32 = ltmp;
      continue;
    case FFIDL_UINT64:
      cif->avalues[i].v_uint64 = ltmp;
      continue;
    case FFIDL_SINT64:
      cif->avalues[i].v_sint64 = ltmp;
      continue;
    case FFIDL_STRUCT:
      if (obj->typePtr != ffidl_bytearray_ObjType) {
	sprintf(buff, "parameter %d must be a binary string", i);
	Tcl_AppendResult(interp, buff, NULL);
	return TCL_ERROR;
      }
      cif->args[i] = (void *)Tcl_GetByteArrayFromObj(obj, &itmp);
      if (itmp != cif->atypes[i]->type->size) {
	sprintf(buff, "parameter %d is the wrong size, %d bytes instead of %d.", i, itmp, cif->atypes[i]->type->size);
	Tcl_AppendResult(interp, buff, NULL);
	return TCL_ERROR;
      }
      continue;
    case FFIDL_PTR:
      cif->avalues[i].v_pointer = (void *)ltmp;
      continue;
    case FFIDL_PTR_OBJ:
      cif->avalues[i].v_pointer = obj;
      continue;
    case FFIDL_PTR_UTF8:
      cif->avalues[i].v_pointer = Tcl_GetString(obj);
      continue;
    case FFIDL_PTR_UTF16:
      cif->avalues[i].v_pointer = Tcl_GetUnicode(obj);
      continue;
    case FFIDL_PTR_BYTE:
      if (obj->typePtr != ffidl_bytearray_ObjType) {
	sprintf(buff, "parameter %d must be a binary string", i);
	Tcl_AppendResult(interp, buff, NULL);
	return TCL_ERROR;
      }
      cif->avalues[i].v_pointer = Tcl_GetByteArrayFromObj(obj, &itmp);
      continue;
    case FFIDL_PTR_VAR:
      obj = Tcl_ObjGetVar2(interp, objv[1+i], NULL, TCL_LEAVE_ERR_MSG);
      if (obj == NULL) return TCL_ERROR;
      if (obj->typePtr != ffidl_bytearray_ObjType) {
	sprintf(buff, "parameter %d must be a binary string", i);
	Tcl_AppendResult(interp, buff, NULL);
	return TCL_ERROR;
      }
      if (Tcl_IsShared(obj)) {
	obj = Tcl_ObjSetVar2(interp, objv[1+i], NULL, Tcl_DuplicateObj(obj), TCL_LEAVE_ERR_MSG);
	if (obj == NULL) return TCL_ERROR;
      }
      cif->avalues[i].v_pointer = Tcl_GetByteArrayFromObj(obj, &itmp);
      Tcl_InvalidateStringRep(obj);
      continue;
    default:
      sprintf(buff, "unknown type for argument: %d", cif->atypes[i]->t);
      Tcl_AppendResult(interp, buff, NULL);
      return TCL_ERROR;
    }
  }
  /* prepare for structure return */
  if (cif->rtype->t == FFIDL_STRUCT) {
    obj = Tcl_NewByteArrayObj("", cif->rtype->type->size);
    Tcl_IncrRefCount(obj);
    cif->ret = Tcl_GetByteArrayFromObj(obj, &itmp);
  }
  /* call */
  ffi_call(&cif->cif, proc->fn, cif->ret, cif->args);
  /* convert return value */
  switch (cif->rtype->t) {
  case FFIDL_VOID:	break;
  case FFIDL_INT:	Tcl_SetObjResult(interp, Tcl_NewLongObj((long)cif->rvalue.v_int)); break;
  case FFIDL_FLOAT:	Tcl_SetObjResult(interp, Tcl_NewDoubleObj((double)cif->rvalue.v_float)); break;
  case FFIDL_DOUBLE:	Tcl_SetObjResult(interp, Tcl_NewDoubleObj((double)cif->rvalue.v_double)); break;
  case FFIDL_LONGDOUBLE:Tcl_SetObjResult(interp, Tcl_NewDoubleObj((double)cif->rvalue.v_longdouble)); break;
  case FFIDL_UINT8:	Tcl_SetObjResult(interp, Tcl_NewLongObj((long)cif->rvalue.v_uint8)); break;
  case FFIDL_SINT8:	Tcl_SetObjResult(interp, Tcl_NewLongObj((long)cif->rvalue.v_sint8)); break;
  case FFIDL_UINT16:	Tcl_SetObjResult(interp, Tcl_NewLongObj((long)cif->rvalue.v_uint16)); break;
  case FFIDL_SINT16:	Tcl_SetObjResult(interp, Tcl_NewLongObj((long)cif->rvalue.v_sint16)); break;
  case FFIDL_UINT32:	Tcl_SetObjResult(interp, Tcl_NewLongObj((long)cif->rvalue.v_uint32)); break;
  case FFIDL_SINT32:	Tcl_SetObjResult(interp, Tcl_NewLongObj((long)cif->rvalue.v_sint32)); break;
  case FFIDL_UINT64:	Tcl_SetObjResult(interp, Tcl_NewLongObj((long)cif->rvalue.v_uint64)); break;
  case FFIDL_SINT64:	Tcl_SetObjResult(interp, Tcl_NewLongObj((long)cif->rvalue.v_sint64)); break;
  case FFIDL_STRUCT:	Tcl_SetObjResult(interp, obj); Tcl_DecrRefCount(obj); break;
  case FFIDL_PTR:	Tcl_SetObjResult(interp, Tcl_NewLongObj((long)cif->rvalue.v_pointer)); break;
  case FFIDL_PTR_OBJ:	Tcl_SetObjResult(interp, (Tcl_Obj *)cif->rvalue.v_pointer); break;
  case FFIDL_PTR_UTF8:	Tcl_SetObjResult(interp, Tcl_NewStringObj(cif->rvalue.v_pointer, -1)); break;
  case FFIDL_PTR_UTF16:	Tcl_SetObjResult(interp, Tcl_NewUnicodeObj(cif->rvalue.v_pointer, -1)); break;
  default:
    sprintf(buff, "Invalid return type: %d", cif->rtype->t);
    Tcl_AppendResult(interp, buff, NULL);
    return TCL_ERROR;
  }    
  /* done */
  return TCL_OK;
} 

/* usage: ffidl-proc name {?argument_type ...?} return_type address -> */
static int tcl_ffidl_proc(ClientData clientData, Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[])
{
  char *name;
  void (*fn)();
  int argc, i, tmp;
  Tcl_Obj **argv;
  Tcl_DString signature, usage;
  ffidl_cif *cif;
  ffi_type *rtype, **atypes;
  ffidl_proc *proc;
  ffidl_client *client = (ffidl_client *)clientData;
  /* usage check */
  if (objc != 5) {
    Tcl_WrongNumArgs(interp, 1, objv, "name {?argument_type ...?} return_type address");
    return TCL_ERROR;
  }
  /* fetch name */
  name = Tcl_GetString(objv[1]);
  /* fetch argument types */
  if (Tcl_ListObjGetElements(interp, objv[2], &argc, &argv) == TCL_ERROR) return TCL_ERROR;
  /* fetch function pointer */
  if (Tcl_GetIntFromObj(interp, objv[4], &tmp) == TCL_ERROR) return TCL_ERROR;
  fn = (void (*)())tmp;
  /* build the cif signature key */
  Tcl_DStringInit(&signature);
  Tcl_DStringAppend(&signature, Tcl_GetString(objv[3]), -1);
  Tcl_DStringAppend(&signature, "(", 1);
  for (i = 0; i < argc; i += 1) {
    if (i != 0) Tcl_DStringAppend(&signature, ",", 1);
    Tcl_DStringAppend(&signature, Tcl_GetString(argv[i]), -1);
  }
  Tcl_DStringAppend(&signature, ")", 1);
  /* lookup the signature in the cif hash */
  cif = cif_lookup(client, Tcl_DStringValue(&signature));
  if (cif == NULL) {
    /* allocate storage for:
       the ffidl_cif,
       the argument ffi_type pointers,
       the argument ffidl_types,
       the argument values,
       and the argument value pointers.
    */
    cif = (ffidl_cif *)ckalloc(sizeof(ffidl_cif)
			       +argc*sizeof(ffi_type*)
			       +argc*sizeof(ffidl_type*)
			       +argc*sizeof(ffidl_value)
			       +argc*sizeof(void*));
    if (cif == NULL) {
      Tcl_AppendResult(interp, "couldn't allocate the ffidl_cif", NULL); 
      Tcl_DStringFree(&signature);
      return TCL_ERROR;
    }
    /* initialize the cif */
    cif->refs = 0;
    cif->client = client;
    atypes = (ffi_type **)(cif+1);
    cif->atypes = (ffidl_type **)(atypes+argc);
    cif->avalues = (ffidl_value *)(cif->atypes+argc);
    cif->args = (void **)(cif->avalues+argc);
    /* parse return value spec */
    if (type_parse(interp, client, FFIDL_RET, objv[3], &rtype, &cif->rtype, &cif->rvalue, &cif->ret) == TCL_ERROR) {
      Tcl_Free((void *)cif);
      Tcl_DStringFree(&signature);
      return TCL_ERROR;
    }
    /* parse arg specs */
    for (i = 0; i < argc; i += 1)
      if (type_parse(interp, client, FFIDL_ARG, argv[i],
		     &atypes[i], &cif->atypes[i], &cif->avalues[i], &cif->args[i]) == TCL_ERROR) {
	Tcl_Free((void *)cif);
	Tcl_DStringFree(&signature);
	return TCL_ERROR;
      }
    /* see if we done right */
    if (ffi_prep_cif(&cif->cif, FFI_DEFAULT_ABI, argc, rtype, atypes) != FFI_OK) {
      Tcl_AppendResult(interp, "type definition error", NULL);
      Tcl_Free((void *)cif);
      Tcl_DStringFree(&signature);
      return TCL_ERROR;
    }
    /* define the cif */
    cif_define(client, Tcl_DStringValue(&signature), cif);
    Tcl_ResetResult(interp);
  }
  /* free the signature string */
  Tcl_DStringFree(&signature);
  /* mark the cif as referenced */
  cif_inc_ref(cif);
  /* if proc is already defined, redefine it */
  if (proc = proc_lookup(client, name)) {
    Tcl_DeleteCommand(interp, name);
  }
  /* build the usage string */
  Tcl_DStringInit(&usage);
  for (i = 0; i < argc; i += 1) {
    if (i != 0) Tcl_DStringAppend(&usage, " ", 1);
    Tcl_DStringAppend(&usage, Tcl_GetString(argv[i]), -1);
  }
  /* allocate the proc structure */
  proc = (ffidl_proc *)ckalloc(sizeof(ffidl_proc)+Tcl_DStringLength(&usage)+1);
  if (proc == NULL) {
    Tcl_DStringFree(&usage);
    cif_dec_ref(cif);
    Tcl_AppendResult(interp, "can't allocate ffidl_proc for: ", name, NULL);
    return TCL_ERROR;
  }
  /* initialize the proc */
  proc->cif = cif;
  proc->fn = fn;
  proc->client = client;
  strcpy(proc->usage, Tcl_DStringValue(&usage));
  /* free the usage string */
  Tcl_DStringFree(&usage);
  /* define the proc */
  proc_define(client, name, proc);
  /* create the tcl command */
  Tcl_CreateObjCommand(interp, name, tcl_ffidl_call, (ClientData) proc, proc_delete);
  return TCL_OK;
}

/* usage: ffidl-symbol library symbol -> address */
static int tcl_ffidl_symbol(ClientData clientData, Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[])
{
  char *library, *symbol, *error, *native;
  void *handle, *address;
  Tcl_DString ds, newName;
  ffidl_client *client = (ffidl_client *)clientData;

  if (objc != 3) {
    Tcl_WrongNumArgs(interp,1,objv,"library symbol");
    return TCL_ERROR;
  }

  library = Tcl_GetString(objv[1]);
  handle = lib_lookup(client, library);

  if (handle == NULL) {
    native = Tcl_UtfToExternalDString(NULL, library, -1, &ds);
    handle = dlopen(strlen(native)?native:NULL, RTLD_NOW | RTLD_GLOBAL);
    Tcl_DStringFree(&ds);
    if (handle == NULL) {
      error = dlerror();
      Tcl_AppendResult(interp, "couldn't load file \"", library, "\": ", error, (char *) NULL);
      return TCL_ERROR;
    }
    lib_define(client, library, handle);
  }

  /* 
   * Some platforms still add an underscore to the beginning of symbol
   * names.  If we can't find a name without an underscore, try again
   * with the underscore.
   */

  symbol = Tcl_GetString(objv[2]);
  native = Tcl_UtfToExternalDString(NULL, symbol, -1, &ds);
  error = dlerror();
  address = dlsym(handle, native);	
  if (error = dlerror()) {
    Tcl_DStringInit(&newName);
    Tcl_DStringAppend(&newName, "_", 1);
    native = Tcl_DStringAppend(&newName, native, -1);
    address =  dlsym(handle, native);
    Tcl_DStringFree(&newName);
  }
  Tcl_DStringFree(&ds);

  if (error = dlerror()) {
    Tcl_AppendResult(interp, "couldn't find symbol\"", symbol, "\": ", error, NULL);
    return TCL_ERROR;
  }

  Tcl_SetObjResult(interp, Tcl_NewIntObj((int)address));
  return TCL_OK;
}

/*
 * One function exported for pointer punning with ffidl-proc.
 */
void *ffidl_pointer_pun(void *p) { return p; }

/*
 *--------------------------------------------------------------
 *
 * Ffidl_Init
 *
 * Results:
 *	None
 *
 * Side effects:
 *	None
 *
 *--------------------------------------------------------------
 */
int Ffidl_Init(Tcl_Interp *interp)
{
  ffidl_client *client;

  if (Tcl_InitStubs(interp, "8.0", 0) == NULL) {
    return TCL_ERROR;
  }
  if (Tcl_PkgRequire(interp, "Tcl", TCL_VERSION, 0) == NULL
      && TCL_VERSION[0] == '7'
      && Tcl_PkgRequire(interp, "Tcl", "8.0", 0) == NULL) {
    return TCL_ERROR;
  }
  if (Tcl_PkgProvide(interp, "Ffidl", Ffidl_VERSION) != TCL_OK) {
    return TCL_ERROR;
  }

  /* allocate type and proc hash for this load */
  client = (ffidl_client *)ckalloc(sizeof(ffidl_client));
  Tcl_InitHashTable(&client->types, TCL_STRING_KEYS);
  Tcl_InitHashTable(&client->procs, TCL_STRING_KEYS);
  Tcl_InitHashTable(&client->cifs, TCL_STRING_KEYS);
  Tcl_InitHashTable(&client->libs, TCL_STRING_KEYS);

  /* initialize types */
  type_define(client, "void", &ffidl_type_void);
  type_define(client, "signed char", &ffidl_type_schar);
  type_define(client, "unsigned char", &ffidl_type_uchar);
  type_define(client, "short", &ffidl_type_sshort);
  type_define(client, "unsigned short", &ffidl_type_ushort);
  type_define(client, "int", &ffidl_type_sint);
  type_define(client, "unsigned", &ffidl_type_uint);
  type_define(client, "long", &ffidl_type_slong);
  type_define(client, "unsigned long", &ffidl_type_ulong);
  type_define(client, "long long", &ffidl_type_slonglong);
  type_define(client, "unsigned long long", &ffidl_type_ulonglong);
  type_define(client, "float", &ffidl_type_float);
  type_define(client, "double", &ffidl_type_double);
  type_define(client, "long double", &ffidl_type_longdouble);
  type_define(client, "sint8", &ffidl_type_sint8);
  type_define(client, "uint8", &ffidl_type_uint8);
  type_define(client, "sint16", &ffidl_type_sint16);
  type_define(client, "uint16", &ffidl_type_uint16);
  type_define(client, "sint32", &ffidl_type_sint32);
  type_define(client, "uint32", &ffidl_type_uint32);
  type_define(client, "sint64", &ffidl_type_sint64);
  type_define(client, "uint64", &ffidl_type_uint64);
  type_define(client, "pointer", &ffidl_type_pointer);
  type_define(client, "pointer-obj", &ffidl_type_pointer_obj);
  type_define(client, "pointer-utf8", &ffidl_type_pointer_utf8);
  type_define(client, "pointer-utf16", &ffidl_type_pointer_utf16);
  type_define(client, "pointer-byte", &ffidl_type_pointer_byte);
  type_define(client, "pointer-var", &ffidl_type_pointer_var);
    
  /* initialize commands */
  Tcl_CreateObjCommand(interp,"ffidl-info", tcl_ffidl_info, (ClientData) client, NULL);
  Tcl_CreateObjCommand(interp,"ffidl-typedef", tcl_ffidl_typedef, (ClientData) client, NULL);
  Tcl_CreateObjCommand(interp,"ffidl-symbol", tcl_ffidl_symbol, (ClientData) client, NULL);
  Tcl_CreateObjCommand(interp,"ffidl-proc", tcl_ffidl_proc, (ClientData) client, NULL);

  /* determine endian */
  {
    union {
      int i;
      char b[4];
    } u;
    u.i = 0x00112233;
    ffidl_little_endian = u.b[0] == 0x33;
  }

  /* determine Tcl_ObjType * for some types */
  ffidl_bytearray_ObjType = Tcl_GetObjType("bytearray");
  ffidl_int_ObjType = Tcl_GetObjType("int");
  ffidl_double_ObjType = Tcl_GetObjType("double");

  /* done */
  return TCL_OK;
}
