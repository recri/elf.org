/*
** doodle - a scribble clone for the pilot.
**
** Copyright 1997, Roger E Critchlow Jr., San Francisco, California.
** All rights reserved.  Fair use permitted.  Caveat emptor.  No warranty.
**
** Pending:
**	put momentum on the pen
*/

/* Application type identifier */
#ifndef AppType
#define AppType	0x7263444F	/* 'rcDO' */
#endif

/* Application version - decimal number of tenths */
#ifndef AppVersion
#define AppVersion 1
#endif

/* Database type */
#ifndef DBType
#define DBType	0x44617461	/* 'Data' */
#endif

/* Database name */
#ifndef DBName
#define DBName "DoodleDB"
#endif

/* Number of pixels allowed in a pen */
#ifndef NPENPIX
#define NPENPIX	32
#endif

/*
** Resource identifiers
*/
#define formDoodle	1000
#define formTDoodle	2000
#define menuDoodle	3000
#define aboutDoodle	4000

/*
** Operations.
*/

#define penFine		'.'
#define penMedium	bulletChr
#define penBroad	'@'
#define penFineItalic	','
#define penMediumItalic	'/'
#define penBroadItalic	';'

#define inkWhite	'0'
#define inkDith12	'1'
#define inkDith25	'2'
#define inkDith37	'3'
#define inkDith50	'4'
#define inkDith62	'5'
#define inkDith75	'6'
#define inkDith87	'7'
#define inkBlack	'8'
#define inkRandom	'9'

#define modePaint	'p'
#define modeSmear	's'

#define cmdAbout	'a'
#define cmdClear	'c'
#define cmdFill		'f'
#define cmdRemove	'r'
#define cmdTitle	't'
#define cmdNew		'n'

/*
** PalmOS includes
*/
#include <Common.h>
/* #include <syscall.h> */
/* #include <subcall.h> */
#include <System/SysAll.h>
#include <UI/UIAll.h>

/*
** Global data structure.
*/
typedef struct {
  DmOpenRef dbR;			/* database handle */
  WinHandle winM;			/* main window */
  short x, y, lx, ly, skip;		/* drawing coordinates */
					/* begin true preferences */
  UInt formID;				/* titled or untitled */
  RectangleType r;			/* current drawing window */
  UInt mode;				/* drawing mode */
  short dbI;				/* page record */
  unsigned char penpix[NPENPIX];	/* pen coordinate offsets */
  unsigned char inkpat[8];		/* current ink pattern */
} data;

data main = {
  0,
  0,
  0, 0, 0, 0, 1,
					/* begin true preferences */
  formTDoodle, 
  { 0, 16, 160, 144 },
  modePaint,
  0,
  "\x88",
  "\xff\xff\xff\xff\xff\xff\xff\xff"
};

#define abort(msg)	ErrDisplayFileLineMsg(__FILE__, __LINE__, msg)

/*
** LabelImage - put the page number in the title bar, or erase it.
*/
void LabelImage(data *d, Boolean draw)
{
  if (d->formID == formTDoodle) {
    char temp[8];
    StrIToA(temp, d->dbI+1);
    if (draw)
      WinDrawChars(temp, StrLen(temp), 120, 1);
    else
      WinEraseChars(temp, StrLen(temp), 120, 1);
  }
}

/*
** MakeImage - create a new image record.
*/
void MakeImage(data *d)
{
  VoidHand t;
  t = DmNewRecord(d->dbR, &d->dbI, 3200);
  DmSet(MemHandleLock(t), 0, 3200, 0);
  MemHandleUnlock(t);
  DmReleaseRecord(d->dbR, d->dbI, true);
}

/*
** LoadImage - copy the database record d->dbI onto the current display.
*/
void LoadImage(data *d)
{
  VoidHand t;
  Word error;
  t = DmQueryRecord(d->dbR, d->dbI);
  if ( ! t) {
    MakeImage(d);
    t = DmQueryRecord(d->dbR, d->dbI);
  }
  MemMove(WinGetWindowPointer(d->winM)->displayAddr+d->r.topLeft.y*20, MemHandleLock(t), d->r.extent.y*20);
  MemHandleUnlock(t);
  LabelImage(d, true);
}

/*
** SaveImage - copy the current display into the database record d->dbI.
*/
void SaveImage(data *d)
{
  VoidHand t;
  LabelImage(d, false);
  t = DmGetRecord(d->dbR, d->dbI);
  if ( ! t) abort("SaveImage failed to Get");
  MenuEraseStatus(NULL);
  DmWrite(MemHandleLock(t), 0, WinGetWindowPointer(d->winM)->displayAddr+d->r.topLeft.y*20, d->r.extent.y*20);
  MemHandleUnlock(t);
  DmReleaseRecord(d->dbR, d->dbI, true);
}

/*
** Load a pen pattern
*/
void LoadPen(data *d, unsigned char *p)
{
  StrCopy(d->penpix, p);
}

/*
** Load an ink pattern
*/
void LoadInk(data *d, long l0, long l1)
{
  ((long *)(d->inkpat))[0] = l0;
  ((long *)(d->inkpat))[1] = l1;
  WinSetPattern((unsigned short *)d->inkpat);
  d->mode = modePaint;
}

/*
** Random integer in the range 0..(n-1).
*/
UInt RandomLessThan(UInt n)
{
  return SysRandom(0) / (1+sysRandomMax/n);
}

/*
** Shuffle the current ink pattern.
*/
void ShuffleInk(data *d)
{
  int i, j, k;
  SysRandom(*(long *)d->inkpat);
  for (i = 0; i < 8; i += 1) {
    j = i + RandomLessThan(8-i);
    k = d->inkpat[i];
    d->inkpat[i] = d->inkpat[j];
    d->inkpat[j] = k;
  }
  WinSetPattern((unsigned short *)d->inkpat);
  d->mode = modePaint;
}

/*
** DoodleEvent - handle events on the doodling form.
*/
Boolean DoodleEvent(EventPtr e)
{
  data *d = &main;
  Boolean handled = false;
  UInt chr;

  switch (e->eType) {

  case frmOpenEvent:

  LoadScreen:
    d->winM = FrmGetWindowHandle(FrmGetActiveForm());
    FrmDrawForm(FrmGetActiveForm());
    if (d->formID == formDoodle)
      RctSetRectangle(&d->r, 0, 0, 160, 160);
    else
      RctSetRectangle(&d->r, 0, 16, 160, 144);
    LoadImage(d);
    WinSetPattern((unsigned short *)d->inkpat);
    handled = true;
    break;

  case appStopEvent:
  case frmCloseEvent:
    SaveImage(d);
    handled = true;
    break;

  case menuEvent:
    chr = e->data.menu.itemID-menuDoodle;
    goto KeyDown;

  case keyDownEvent:
    chr = e->data.keyDown.chr;
  KeyDown:
    switch (chr) {
      
    case penFine:	  LoadPen(d, "\x88"); break;
    case penMedium:	  LoadPen(d, "\x88\x98\x89\x99"); break;
    case penBroad:	  LoadPen(d, "\x66\x76\x86\x96\xA6\x67\xA7\x68\xA8\x69\x79\x89\x99\xA9"); break;
    case penFineItalic:	  LoadPen(d, "\x78\x88\x87\x97"); break;
    case penMediumItalic: LoadPen(d, "\x69\x79\x78\x88\x87\x97\x96\xA6"); break;
    case penBroadItalic:  LoadPen(d, "\x5A\x6A\x69\x79\x78\x88\x87\x97\x96\xA6\xA5\xB5"); break;

    case inkWhite:  LoadInk(d, 0x00000000L, 0x00000000L); break;
    case inkDith12: LoadInk(d, 0x11004400L, 0x11004400L); break;
    case inkDith25: LoadInk(d, 0x11224488L, 0x11224488L); break;
    case inkDith37: LoadInk(d, 0x512a45a8L, 0x15a2548aL); break;
    case inkDith50: LoadInk(d, 0xaa55aa55L, 0xaa55aa55L); break;
    case inkDith62: LoadInk(d, 0xaed5ba57L, 0xea5dab75L); break;
    case inkDith75: LoadInk(d, 0xeeddbb77L, 0xeeddbb77L); break;
    case inkDith87: LoadInk(d, 0xeeffbbffL, 0xeeffbbffL); break;
    case inkBlack:  LoadInk(d, 0xffffffffL, 0xffffffffL); break;
    case inkRandom: ShuffleInk(d); break;

    case modePaint:
    case modeSmear:
      d->mode = chr;
      break;

    case cmdAbout:
      FrmAlert(aboutDoodle);
      break;

    case cmdTitle:
      SaveImage(d);
      FrmGotoForm(d->formID == formDoodle ? formTDoodle : formDoodle);
      break;

    case cmdClear:
      WinEraseRectangle(&d->r, 0);
      break;

    case cmdFill:
      WinFillRectangle(&d->r, 0);
      break;

    case cmdNew:
      SaveImage(d);
      d->dbI += 1;
      MakeImage(d);
      LoadImage(d);
      break;

    case cmdRemove:
      SaveImage(d);
      DmRemoveRecord(d->dbR, d->dbI);
      if (d->dbI == DmNumRecords(d->dbR)) {
	if (d->dbI == 0)
	  MakeImage(d);
	else 
	  d->dbI -= 1;
      }
      LoadImage(d);
      break;

    case pageUpChr:
    case pageDownChr:
      SaveImage(d);
      d->dbI += chr==pageDownChr ? 1 : -1;
      if (d->dbI < 0)
	d->dbI = 0;
      else if (d->dbI == DmNumRecords(d->dbR))
	d->dbI -= 1;
      LoadImage(d);
      break;

    }
    handled = true;
    break;

  case penDownEvent:
#define rctPtInRectangle(tx,ty,rp) (((unsigned)((tx)-(rp)->topLeft.x)<(rp)->extent.x) && ((unsigned)((ty)-(rp)->topLeft.y)<(rp)->extent.y))
    if ( ! rctPtInRectangle(e->screenX, e->screenY, &d->r)) { d->skip = 1; break; }
    d->skip = 0;
    d->lx = e->screenX;
    d->ly = e->screenY;
    handled = true;
    break;

  case penUpEvent:
  case penMoveEvent:
    if ( ! rctPtInRectangle(e->screenX, e->screenY, &d->r)) { d->skip = 1; break; }
    d->x = e->screenX;
    d->y = e->screenY;
    if ( ! d->skip) {
      short i, dx, dy;
      for (i = 0; i < NPENPIX && d->penpix[i] != 0; i += 1) {
#define dxFromPenpix(p)	(((int)(p>>4))-8)
#define dyFromPenpix(p)	(((int)(p&0xF))-8)
	dx = dxFromPenpix(d->penpix[i]);
	dy = dyFromPenpix(d->penpix[i]);
	if ( ! rctPtInRectangle(d->lx+dx, d->ly+dy, &d->r))
	  continue;
	if ( ! rctPtInRectangle(d->x+dx, d->y+dy, &d->r))
	  continue;
	if (d->mode ==  modeSmear)
	  WinInvertLine(d->lx+dx, d->ly+dy, d->x+dx, d->y+dy);
	else
	  WinFillLine(d->lx+dx, d->ly+dy, d->x+dx, d->y+dy);
      }
    }
    d->skip = e->eType == penUpEvent;
    d->lx = d->x;
    d->ly = d->y;
    handled = true;
    break;
  }

  return handled;

}

/*
** PilotMain - handle the toplevel command and event dispatch.
*/
DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags)
{
  EventType e;
  Word error;
  Err err;
  data *d = &main;

  if (cmd == sysAppLaunchCmdNormalLaunch) {
    
    /*
    ** Start application.
    ** Open database,
    ** fetch preferences,
    ** and go to active form
    */
    if ((d->dbR = DmOpenDatabaseByTypeCreator(DBType, AppType, dmModeReadWrite)) != NULL) {
      PrefGetAppPreferences(AppType, AppVersion, d, sizeof(*d));
    } else {
      if (err = DmCreateDatabase(0, DBName, AppType, DBType, false))
	return err;
      d->dbR = DmOpenDatabaseByTypeCreator(DBType, AppType, dmModeReadWrite);
    }

    FrmGotoForm(d->formID);

    /*
    ** Process events.
    */
    do {

      EvtGetEvent(&e, evtWaitForever);

      if (SysHandleEvent(&e)) continue;

      if (MenuHandleEvent(NULL, &e, &error)) continue;

      if (e.eType == frmLoadEvent) {
	FormPtr frm = FrmInitForm(d->formID = e.data.frmLoad.formID);
	FrmSetActiveForm(frm);
	FrmSetEventHandler(frm, DoodleEvent);
	continue;
      }

      FrmDispatchEvent(&e);

    } while (e.eType != appStopEvent);

    /*
    ** Stop application.
    ** Save preferences, and close database.
    */
    PrefSetAppPreferences(AppType, AppVersion, d, sizeof(*d));
    DmCloseDatabase(d->dbR);
  }

  return(0);

}

