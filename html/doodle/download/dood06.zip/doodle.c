/*
** doodle - a scribble clone for the pilot.
**
** Copyright 1997, Roger E Critchlow Jr., San Francisco, California.
** All rights reserved.  Fair use permitted.  Caveat emptor.  No warranty.
**
** Pending:
**	put momentum on the pen
*/

#include "doodle.h"

/* Number of pixels allowed in a pen */
#ifndef NPENPIX
#define NPENPIX	32
#endif

/* Number of pen events which may be weighted together */
#ifndef NPENWTS
#define NPENWTS 8		/* must be power of two */
#endif

/*
** Resource identifiers
*/
#define formDoodle	1000
#define formTDoodle	2000
#define ctlMode		2100
#define ctlSmooth	2200
#define ctlPen		2300
#define ctlInk		2400
#define ctlPage		2500
#define menuDoodle	3000
#define aboutDoodle	4000

/*
** Operations.
*/

#define penFine		'.'
#define penMedium	bulletChr
#define penBroad	'@'
#define penFineItalic	','
#define penMediumItalic	'/'
#define penBroadItalic	';'

#define inkWhite	'0'
#define inkDith12	'1'
#define inkDith25	'2'
#define inkDith37	'3'
#define inkDith50	'4'
#define inkDith62	'5'
#define inkDith75	'6'
#define inkDith87	'7'
#define inkBlack	'8'
#define inkRandom	'9'

#define modeErase	'e'
#define modePaint	'p'
#define modeSmear	's'
#define cmdRough	'<'
#define cmdSmooth	'='
#define cmdSmoother	'>'

#define cmdAbout	'a'
#define cmdClear	'c'
#define cmdFill		'f'
#define cmdRemove	'r'
#define cmdTitle	't'
#define cmdNew		'n'
#define cmdDuplicate	'd'
#define cmdPrevious	'-'
#define cmdNext		'+'

/*
** PalmOS includes
*/
#include <Pilot.h>

/*
** Global data structure.
*/
typedef struct {
  DmOpenRef dbR;			/* database handle */
  WinHandle winM;			/* main window */
  struct wts {
    unsigned short x, y;		/* incoming pen coordinates */
  } wts[NPENWTS];
  unsigned short nwts;			/* pen event coordinates */
  unsigned short wx, wy;		/* sum of pwt pen coordinates */
  unsigned short ox, oy;		/* last synthesized pen coordinates */
} data;

typedef struct {
  unsigned int version;			/* version number */
  short dbI;				/* page record */
  unsigned int formID;			/* titled or untitled */
  RectangleType r;			/* current drawing window */
  char mode_label[2];			/* mode label for title and increment */
  char filt_label[2];			/* filter lable for title and increment */
  char pen_label[2];			/* pen label for increment */
  char ink_label[2];			/* ink label for increment */
  unsigned short filt;			/* pen event weighting */
  unsigned char penpix[NPENPIX];	/* pen coordinate offsets */
  unsigned short inkpat[4];		/* current ink pattern */
} pref;

data d;					/* initialized to zero */

pref p = {
  AppVersion, 
  0,
  formTDoodle, 
  { 0, 16, 160, 144 },
  "p", "=", ".", "8",
  4,
  "\x88",
  { 0xffff, 0xffff, 0xffff, 0xffff }
};

#if 0
#define abort(msg)	ErrDisplayFileLineMsg(__FILE__, __LINE__, msg)
#else
#define abort(msg)	ErrDisplayFileLineMsg(__FILE__, __LINE__, "")
#endif

/*
** Extract the pen pixel offsets from the penpex array bytes.
** Each nibble is treated as a 2's complement integer.
*/
#define dxFromPenpix(p)	(((int)(p>>4))-8)
#define dyFromPenpix(p)	(((int)(p&0xF))-8)

/*
** Default penpixel set.
*/

char penpixFine[] =		"\x88";
char penpixMedium[] =		"\x88\x98\x89\x99";
char penpixBroad[] =		"\x66\x76\x86\x96\xA6\x67\xA7\x68\xA8\x69\xA9\x6A\x7A\x8A\x9A\xAA";
char penpixFineItalic[] =	"\x78\x88\x87\x97";
char penpixMediumItalic[] =	"\x69\x79\x78\x88\x87\x97\x96\xA6";
char penpixBroadItalic[] =	"\x5A\x6A\x69\x79\x78\x88\x87\x97\x96\xA6\xA5\xB5";
RectangleType penr = { 47+2*14+2*4, 1, 14, 10 };

/*
** Default ink pattern set.
*/
unsigned short patternWhite[] =  { 0x0000, 0x0000, 0x0000, 0x0000 };
unsigned short patternDith12[] = { 0x1100, 0x4400, 0x1100, 0x4400 };
unsigned short patternDith25[] = { 0x2211, 0x4488, 0x2211, 0x4488 };
unsigned short patternDith37[] = { 0xc84c, 0x2331, 0x8cc4, 0x3213 };
unsigned short patternDith50[] = { 0xaa55, 0xaa55, 0xaa55, 0xaa55 };
unsigned short patternDith62[] = {~0xc84c,~0x2331,~0x8cc4,~0x3213 };
unsigned short patternDith75[] = {~0x2211,~0x4488,~0x2211,~0x4488 };
unsigned short patternDith87[] = {~0x1100,~0x4400,~0x1100,~0x4400 };
unsigned short patternBlack[] =  {~0x0000,~0x0000,~0x0000,~0x0000 };
RectangleType inkr = { 47+3*14+3*4, 1, 14, 10 };

/*
** SetLabel - set the label of a control on the current form.
*/
static void SetLabel(Int objectID, char *label)
{
  FormPtr frm;
	
  frm = FrmGetActiveForm();
  CtlSetLabel(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, objectID)), label);
}

/*
** LabelImage - put the program state in the title bar
*/
static void LabelImage(void)
{
  if (p.formID == formTDoodle) {
    char temp[8];
    short i, x, y;
    /* Show mode label */
    SetLabel(ctlMode, p.mode_label);
    /* Show filter label */
    SetLabel(ctlSmooth, p.filt_label);
    /* Show current pen */
    WinSetPattern(patternBlack);
    WinEraseRectangle(&penr, 4);
    for (i = 0; i < NPENPIX && p.penpix[i] != 0; i += 1) {
      x = 47+2*14+2*4+6+dxFromPenpix(p.penpix[i]);
      y = 1+4+dyFromPenpix(p.penpix[i]);
      WinFillLine(x, y, x, y);
    }
    /* Show current ink */
    WinSetPattern(p.inkpat);
    WinFillRectangle(&inkr, 4);
    /* Show current page number */
    StrIToA(temp, p.dbI+1);
    SetLabel(ctlPage, temp);
  }
}

/*
** AllocImage - create a new image record.
*/
static void AllocImage(void)
{
  VoidHand t;
  t = DmNewRecord(d.dbR, &p.dbI, 3200);
  if ( ! t) abort("out of memory?");
  DmReleaseRecord(d.dbR, p.dbI, true);
}

/*
** ClearImage - clear a new image record.
*/
inline static void ClearImage(void)
{
  VoidHand t;
  t = DmGetRecord(d.dbR, p.dbI);
  if ( ! t) abort("ClearImage failed to Get");
  DmSet(MemHandleLock(t), 0, 3200, 0);
  MemHandleUnlock(t);
  DmReleaseRecord(d.dbR, p.dbI, true);
}

/*
** MakeImage - create a new empty image record.
*/
static void MakeImage(void)
{
  AllocImage();
  ClearImage();
}

/*
** LoadImage - copy the database record p.dbI onto the current display.
*/
static void LoadImage(void)
{
  VoidHand t;
  Word error;
  t = DmQueryRecord(d.dbR, p.dbI);
  if ( ! t) {
    MakeImage();
    t = DmQueryRecord(d.dbR, p.dbI);
    if (! t) abort("LoadImage failed to load");
  }
  MemMove(WinGetWindowPointer(d.winM)->displayAddr+p.r.topLeft.y*20, MemHandleLock(t), p.r.extent.y*20);
  MemHandleUnlock(t);
}

/*
** SaveImage - copy the current display into the database record p.dbI.
*/
static void SaveImage(void)
{
  VoidHand t;
  t = DmGetRecord(d.dbR, p.dbI);
  if ( ! t) abort("SaveImage failed to Get");
  MenuEraseStatus(NULL);
  DmWrite(MemHandleLock(t), 0, WinGetWindowPointer(d.winM)->displayAddr+p.r.topLeft.y*20, p.r.extent.y*20);
  MemHandleUnlock(t);
  DmReleaseRecord(d.dbR, p.dbI, true);
}

/*
** CopyImage - create a new copy of the current record.
*/
inline static void CopyImage(void)
{
  AllocImage();
  SaveImage();
}

/*
** Load a pen pattern
*/
inline static void LoadPen(UInt chr, unsigned char *pen)
{
  StrCopy(p.penpix, pen);
  p.pen_label[0] = chr;
}

/*
** Random integer in the range 0..(n-1).
*/
inline static UInt RandomLessThan(UInt n)
{
  return SysRandom(0) / (1+sysRandomMax/n);
}

/*
** Load an ink pattern
*/
static void LoadInk(UInt chr, unsigned short *pattern)
{
  if (pattern != NULL) {
    /* Load the specified ink pattern */
    p.ink_label[0] = chr;
    ((long *)(p.inkpat))[0] = ((long *)pattern)[0];
    ((long *)(p.inkpat))[1] = ((long *)pattern)[1];
  } else {
    unsigned i, id, im, ib, j, jd, jm, jb;

    SysRandom(((long *)p.inkpat)[0]+((long *)p.inkpat)[1]);
    for (i = 0; i < 64; i += 1) {
      j = i + RandomLessThan(64-i);
      ib = p.inkpat[id = i/16] & (im = 1<<(i%16));
      jb = p.inkpat[jd = j/16] & (jm = 1<<(j%16));
      if (ib)
	p.inkpat[jd] |= jm;
      else
	p.inkpat[jd] &= ~jm;
      if (jb)
	p.inkpat[id] |= im;
      else
	p.inkpat[id] &= ~im;
    }
  }
  WinSetPattern(p.inkpat);
  p.mode_label[0] = modePaint;
}

/*
** Act on a key (or menu event) received.
*/
static Boolean KeyDown(UInt chr)
{
  /* Map command character to lower case */
  if (chr >= 'A' && chr <= 'Z')
    chr += 'a'-'A';

  /* Dispatch on character */
  switch (chr) {
      
  case penFine:		LoadPen(chr, penpixFine); break;
  case penMedium:	LoadPen(chr, penpixMedium); break;
  case penBroad:	LoadPen(chr, penpixBroad); break;
  case penFineItalic:	LoadPen(chr, penpixFineItalic); break;
  case penMediumItalic: LoadPen(chr, penpixMediumItalic); break;
  case penBroadItalic:  LoadPen(chr, penpixBroadItalic); break;

  case inkWhite:  LoadInk(chr, patternWhite); break;
  case inkDith12: LoadInk(chr, patternDith12); break;
  case inkDith25: LoadInk(chr, patternDith25); break;
  case inkDith37: LoadInk(chr, patternDith37); break;
  case inkDith50: LoadInk(chr, patternDith50); break;
  case inkDith62: LoadInk(chr, patternDith62); break;
  case inkDith75: LoadInk(chr, patternDith75); break;
  case inkDith87: LoadInk(chr, patternDith87); break;
  case inkBlack:  LoadInk(chr, patternBlack); break;
  case inkRandom: LoadInk(chr, NULL); break;

  case modePaint:
  case modeSmear:
  case modeErase:
    p.mode_label[0] = chr;
    break;

  case cmdRough:
    p.filt = 1;
    p.filt_label[0] = chr;
    break;

  case cmdSmooth:
    p.filt = 4;
    p.filt_label[0] = chr;
    break;

  case cmdSmoother:
    p.filt = 8;
    p.filt_label[0] = chr;
    break;

  case cmdAbout:
    FrmAlert(aboutDoodle);
    break;

  case cmdTitle:
    SaveImage();
    FrmGotoForm(p.formID == formDoodle ? formTDoodle : formDoodle);
    break;

  case cmdClear:
    MenuEraseStatus(NULL);
    WinEraseRectangle(&p.r, 0);
    break;

  case cmdFill:
    MenuEraseStatus(NULL);
    WinFillRectangle(&p.r, 0);
    break;

  case cmdNew:
    SaveImage();
    p.dbI += 1;
    MakeImage();
    LoadImage();
    break;

  case cmdDuplicate:
    SaveImage();
    p.dbI += 1;
    CopyImage();
    LoadImage();
    break;

  case cmdRemove:
    SaveImage();
    DmRemoveRecord(d.dbR, p.dbI);
    if (p.dbI > 0)
      p.dbI -= 1;
    else if (p.dbI == DmNumRecords(d.dbR))
      MakeImage();
    LoadImage();
    break;

  case cmdPrevious:
  case pageUpChr: {
    int n = DmNumRecords(d.dbR);
    SaveImage();
    p.dbI = (p.dbI+n-1) % n;
    LoadImage();
    break;
  }

  case cmdNext:
  case pageDownChr:
    SaveImage();
    p.dbI = (p.dbI+1) % DmNumRecords(d.dbR);
    LoadImage();
    break;

  }
  LabelImage();
  return true;
}

/*
** Clear the pen state.
*/
static void DoodlePenClear(void)
{
  d.nwts = d.wx = d.wy = 0;
  MemSet(d.wts, sizeof(d.wts), 0);
}

/*
** Clipping macro -- PalmOS doesn't clip at screen bottom.
*/
#define rctPtInRectangle(tx,ty,rp) \
    (   ((unsigned) ((tx)-(rp)->topLeft.x) < (rp)->extent.x) \
     && ((unsigned) ((ty)-(rp)->topLeft.y) < (rp)->extent.y) )

/*
** Act on a doodle pen event.
*/
static void DoodlePenEvent(enum events etype, short nx, short ny)
{
  if (etype != penDownEvent) {
    short i, dx, dy;
    /* Draw the lines defined by the pen */
    for (i = 0; i < NPENPIX && p.penpix[i] != 0; i += 1) {
      dx = dxFromPenpix(p.penpix[i]);
      dy = dyFromPenpix(p.penpix[i]);
      if ( ! rctPtInRectangle(d.ox+dx, d.oy+dy, &p.r))
	continue;
      if ( ! rctPtInRectangle(nx+dx, ny+dy, &p.r))
	continue;
      if (p.mode_label[0] == modeSmear)
	WinInvertLine(d.ox+dx, d.oy+dy, nx+dx, ny+dy);
      else
	WinFillLine(d.ox+dx, d.oy+dy, nx+dx, ny+dy);
    }
  }
  d.ox = nx;
  d.oy = ny;
}

/*
** Choose the successor to the current choice on some menu.
*/
static unsigned int ChooseSuccessor(int now, unsigned char *choices)
{
  unsigned char *cp = StrChr(choices, now);
  return (cp == NULL || cp[1] == 0) ? choices[0] : cp[1];
}
      
/*
** DoodleEvent - handle events on the doodling form.
*/
static Boolean DoodleEvent(EventPtr e)
{
  Boolean handled = false;
  UInt chr;

  /*
  ** We only set the inkpat here because it was being mysteriously
  ** reset by menu handling.  But having done that, it makes a perfect
  ** place to implement erase.
  */
  WinSetPattern(p.mode_label[0] == modeErase ? patternWhite : p.inkpat);

  switch (e->eType) {

  case frmOpenEvent:

  LoadScreen:
    d.winM = FrmGetWindowHandle(FrmGetActiveForm());
    FrmDrawForm(FrmGetActiveForm());
    if (p.formID == formDoodle)
      RctSetRectangle(&p.r, 0, 0, 160, 160);
    else
      RctSetRectangle(&p.r, 0, 16, 160, 144);
    LoadImage();
    LabelImage();
    handled = true;
    break;

  case appStopEvent:
  case frmCloseEvent:
    SaveImage();
    handled = true;
    break;

  case menuEvent:
    handled = KeyDown(e->data.menu.itemID-menuDoodle);
    break;

  case keyDownEvent:
    handled = KeyDown(e->data.keyDown.chr);
    break;

  case ctlSelectEvent:
    switch (e->data.ctlEnter.controlID) {
    case ctlMode:	handled = KeyDown(ChooseSuccessor(p.mode_label[0], "pse")); break;
    case ctlSmooth:	handled = KeyDown(ChooseSuccessor(p.filt_label[0], "<=>")); break;
    case ctlPen:	handled = KeyDown(ChooseSuccessor(p.pen_label[0], ".�@,/;")); break;
    case ctlInk:	handled = KeyDown(ChooseSuccessor(p.ink_label[0], "012345678")); break;
    case ctlPage:	handled = KeyDown(cmdNext); break;
    }
    break;
  	
  case penDownEvent:
    DoodlePenClear();
    /* fall through */

  case penMoveEvent:
  case penUpEvent:
    {
      Boolean in_bounds = rctPtInRectangle(e->screenX, e->screenY, &p.r);
      unsigned short i, n;

      if (in_bounds) {
	/* Update sum of coordinates */
	n = (d.nwts-p.filt)%NPENWTS;
	d.wx += e->screenX - d.wts[n].x;
	d.wy += e->screenY - d.wts[n].y;

	/* Update array of coordinates */
	n = d.nwts%NPENWTS;
	d.wts[n].x = e->screenX;
	d.wts[n].y = e->screenY;

	/* Send averaged coordinate */
	n = (d.nwts >= p.filt) ? p.filt : d.nwts+1;
	DoodlePenEvent(d.nwts ? e->eType : penDownEvent, d.wx/n, d.wy/n);

	/* Update count of coordinates */
	d.nwts += 1;
      }

      /* Pen up or out of bounds ends the stroke */
      if (e->eType == penUpEvent || ! in_bounds) {
	/* Drain queue */
	short i;
	for (i = (d.nwts < p.filt) ? d.nwts : p.filt; --i > 0; ) {
	  n = (d.nwts-i-1)%NPENWTS;
	  d.wx -= d.wts[n].x;
	  d.wy -= d.wts[n].y;
	  DoodlePenEvent(penMoveEvent, d.wx/i, d.wy/i);
	}
	/* Clear state */
	DoodlePenClear();
      }

      /* leave out of bounds events unhandled */
      handled = in_bounds;
      break;
    }

  }

  return handled;

}

/*
** PilotMain - handle the toplevel command and event dispatch.
*/
DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags)
{
  EventType e;
  Word error;
  Err err;
  LocalID dbID;
  UInt dbAttrs;
  UInt cardNo;

  if (cmd == sysAppLaunchCmdNormalLaunch) {
    
    /*
    ** Start application.
    ** Open database,
    ** fetch preferences,
    ** keep default preferences if version doesn't match.
    */
    if ((d.dbR = DmOpenDatabaseByTypeCreator(DBType, AppType, dmModeReadWrite)) != NULL) {
      PrefGetAppPreferences(AppType, AppVersion, &p.version, sizeof(p.version));
      if (p.version != AppVersion)
	p.version = AppVersion;
      else
	PrefGetAppPreferences(AppType, AppVersion, &p, sizeof(p));
    } else {
      if (err = DmCreateDatabase(0, DBName, AppType, DBType, false))
	return err;
      d.dbR = DmOpenDatabaseByTypeCreator(DBType, AppType, dmModeReadWrite);
    }

    /*
    ** Set the backup flag in the attributes so this database will be backed up.
    ** This adds 136 bytes to the program image.
    */
    if ((err = DmOpenDatabaseInfo(d.dbR, &dbID, NULL, NULL, &cardNo, NULL))
     || (err = DmDatabaseInfo(0, dbID, NULL, &dbAttrs, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL))) {
      DmCloseDatabase(d.dbR);
      return err;
    }
    dbAttrs = dbAttrs | dmHdrAttrBackup;
    if (err = DmSetDatabaseInfo(0, dbID, NULL, &dbAttrs, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)) {
      DmCloseDatabase(d.dbR);
      return err;
    }

    /*
    ** Launch the current form.
    */
    FrmGotoForm(p.formID);

    /*
    ** Process events.
    */
    do {

      EvtGetEvent(&e, evtWaitForever);

      if (SysHandleEvent(&e)) continue;

      if (MenuHandleEvent(NULL, &e, &error)) continue;

      if (e.eType == frmLoadEvent) {
	FormPtr frm = FrmInitForm(p.formID = e.data.frmLoad.formID);
	FrmSetActiveForm(frm);
	FrmSetEventHandler(frm, DoodleEvent);
	continue;
      }

      FrmDispatchEvent(&e);

    } while (e.eType != appStopEvent);

    /*
    ** Stop application.
    ** Save preferences, and close database.
    */
    PrefSetAppPreferences(AppType, AppVersion, &p, sizeof(p));
    DmCloseDatabase(d.dbR);
  }

  return 0;

}

