/*
** doodle-db - maintain a doodle database file under unix using
** the pilot-link libraries and the pbm package.
**
** The doodle database consists of an indefinite number of 160x160
** pixel images, one to each record.
**
** Two operations are implemented:
**
**	-x extract pbm format files from a database
**	-c create a database and append pbm files onto it
**
** From these you can synthesize most of what anyone does to an
** archive file.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <pbm.h>

#include "pi-file.h"

#include "doodle.h"

char *make_pbm_file_name(char *db_file_name, int record)
{
  static int n = 0;
  static char *pbm = NULL;
  if (n == 0 || strlen(db_file_name)+32 > n) {
    if ((pbm = malloc(n = strlen(db_file_name)+32)) == NULL)
      pm_error("failed to allocate name buffer for %s\n", db_file_name);
  }
  strcpy(pbm, db_file_name);
  if (strrchr(pbm, '.') != NULL)
    sprintf(strrchr(pbm, '.'), "%d.pbm", record+1);
  else
    sprintf(pbm+strlen(pbm), "%d.pbm", record+1);
  return pbm;
}

char *make_database_name(char *db_file_name)
{
  static char *db = NULL;
  char *p1, *p2;
  int n;
  if ((p1 = strrchr(db_file_name, '/')) == NULL)
    p1 = db_file_name;
  if ((p2 = strrchr(db_file_name, '.')) == NULL)
    p2 = db_file_name+strlen(db_file_name);
  n = p2-p1;
  if (db == NULL)
    db = malloc(n+1);
  else
    db = realloc(db, n+1);
  if (db == NULL)
    pm_error("failed to allocate name buffer for %s\n", db_file_name);
  strncpy(db, "", n+1);
  strncpy(db, p1, n);
  return db;
}

int main(int argc, char *argv[])
{
  /* Initialize pbm package */
  pbm_init(&argc, argv);

  /* Test for adequate arguments */
  if (argc >= 3) {

    /* Extract doodle database */
    if (strcmp(argv[1], "-x") == 0) {
      struct pi_file *db;
      int i, j, k, size, attr, cat;
      void *bufp;
      pi_uid_t uid;
      FILE *pbm;
      bit **bits = pbm_allocarray(160, 160);

      /* Open Pilot database */
      if ((db = pi_file_open(argv[2])) == NULL)
	pm_error("could not open DoodleDB: %s\n", argv[2]);

      for (i = 0; 1; i += 1) {

	/* Read database record */
	if (pi_file_read_record(db, i, &bufp, &size, &attr, &cat, &uid) != 0)
	  break;

	/* Open pbm file */
	pbm = pm_openw(make_pbm_file_name(argv[2], i));
	/* Translate database record to bits */
	for (j = 0; j < 160; j += 1)
	  for (k = 0; k < 160; k += 1)
	    bits[j][k] = ((char *)bufp)[(j*160+k)/8] & (0x80>>((j*160+k)%8)) ? PBM_BLACK : PBM_WHITE;

	/* Write pbm file */
	pbm_writepbm(pbm, bits, 160, 160, 0);

	/* Close the pbm file */
	pm_close(pbm);
      }

      /* Free the bits */
      pbm_freearray(bits, 160);

      /* Close the database */
      pi_file_close(db);
      
      /* Done */
      return 0;
    }
  
    /* Create doodle database */
    if (strcmp(argv[1], "-c") == 0) { 
      struct DBInfo info = {
	0,			/* more? */
	0,			/* flags? */
	DBType, AppType,	/* type, creator */
	0,			/* version */
	0,			/* modnum */
	0, 0, 0,		/* crdate, moddate, backupdate */
	0,			/* index */
	DBName			/* name */
      };
      struct pi_file *db;
      int i, j, k, rows, cols;
      void *bufp;
      FILE *pbm;
      bit **bits;
      time_t now;

      /* Stuff the name into the DBInfo block */
      strncpy(info.name, make_database_name(argv[2]), 32);

      /* Create pilot database */
      if ((db = pi_file_create(argv[2], &info)) == NULL)
	pm_error("cannot create database %s\n", argv[2]);
    
      /* Allocate a record buffer */
      if ((bufp = malloc(160*160/8)) == NULL)
	pm_error("malloc failed\n");

      /* Intialize our unique id counter */
      time(&now);

      for (i = 3; i < argc; i += 1) {
	/* Open pbm file */
	pbm = pm_openr(argv[i]);

	/* Read pbm file */
	bits = pbm_readpbm(pbm, &cols, &rows);
	
	/* Complain on failure */
	if (bits == NULL)
	  pm_error("could not read pbm from %s\n", argv[i]);

	/* Translate to doodle format */
	for (j = 0; j < 160; j += 1)
	  for (k = 0; k < 160; k += 1)
	    if (j < rows && k < cols && bits[j][k] == PBM_BLACK)
	      ((char *)bufp)[(j*160+k)/8] |= (0x80>>((j*160+k)%8));
	    else
	      ((char *)bufp)[(j*160+k)/8] &= ~(0x80>>((j*160+k)%8));
	      
	/* Write database record */
	if (pi_file_append_record(db, bufp, 160*160/8, 0, 0, now+i) != 0) {
	  pi_file_close(db);
	  pm_error("failed to write record for %s\n", argv[i]);
	}
      }
      
      /* Deallocate the record buffer */
      free(bufp);

      /* Close the database */
      pi_file_close(db);

      return 0;
    }
  }
  
  fprintf(stderr,
	  "usage: %s -x DoodleDB.pdb\n"
	  "or:    %s -c DoodleDB.pdb [file.pbm ...]\n", argv[0],
	  argv[0]);
  return 1;
}
