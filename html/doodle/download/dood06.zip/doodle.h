/* Application type identifier */
#ifndef AppType
#define AppType	0x7263444F	/* 'rcDO' */
#endif

/* Application version - decimal number of tenths */
#ifndef AppVersion
#define AppVersion 6
#endif

/* Database type */
#ifndef DBType
#define DBType	0x44617461	/* 'Data' */
#endif

/* Database name */
#ifndef DBName
#define DBName "DoodleDB"
#endif

