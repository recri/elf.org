/*
** Doodle, a drawing program for palmtop computers running PalmOS.
**
** Doodle is Copyright (c) 1997, 2002 by Roger E Critchlow Jr,
** Santa Fe, New Mexico, USA, rec@elf.org.
**
** Portions of Doodle are derived from DiddleBug.  DiddleBug is
** Copyright (c) 2001 Peter Putzer <pputzer@users.sourceforge.net>
** Copyright (c) 1999,2000 Mitch Blevins <mblevin@debian.org>.
** 
** This file is part of Doodle.
**
** Doodle is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** Doodle is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with Doodle; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <PalmOS.h>
#undef vchrSonyMin
#undef vchrSonyMax
#include <SonyCLIE.h>			// Sony Clie
#include <Vga.h>                // HandEra 330

#include "features.h"

void TestFeatures(Features *features) {
  UInt32 value;

  if (FtrGet(sysFtrCreator, sysFtrNumROMVersion, &value) == 0) {
    features->palmos_2_0 = value >= 0x02003000;
    features->palmos_3_0 = value >= sysMakeROMVersion(3,0,0,sysROMStageRelease,0);
    features->palmos_3_1 = value >= sysMakeROMVersion(3,1,0,sysROMStageRelease,0);
    features->palmos_3_2 = value >= sysMakeROMVersion(3,2,0,sysROMStageRelease,0);
    features->palmos_3_5 = value >= sysMakeROMVersion(3,5,0,sysROMStageRelease,0);
    features->palmos_4_0 = value >= sysMakeROMVersion(4,0,0,sysROMStageRelease,0);
    features->palmos_4_1 = value >= sysMakeROMVersion(4,1,0,sysROMStageRelease,0);
    features->palmos_5_0 = value >= sysMakeROMVersion(5,0,0,sysROMStageRelease,0);
    features->palmos_5_1 = value >= sysMakeROMVersion(5,1,0,sysROMStageRelease,0);
  }
  features->international = FtrGet(sysFtrCreator, sysFtrNumIntlMgr, &value) == 0 && value > 0;
  features->japanese = FtrGet(sysFtrCreator, sysFtrNumEncoding, &value) == 0 && value == charEncodingCP932;
  features->serial_1 = FtrGet(sysFileCSerialMgr, sysFtrNewSerialPresent, &value) == 0 && value > 0;
  features->serial_2 = FtrGet(sysFileCSerialMgr, sysFtrNewSerialPresent, &value) == 0 && value == 2 && features->palmos_4_0;
  features->connection = FtrGet(kCncFtrCncMgrCreator, kCncFtrCncMgrVersion, &value) == 0 && value >= kCncMgrVersion;
  features->notification = FtrGet(sysFtrCreator, sysFtrNumNotifyMgrVersion, &value) == 0 && value != 0;
  features->expansion = FtrGet(sysFileCExpansionMgr, expFtrIDVersion, &value) == 0 && value != 0;
  features->vfs = FtrGet(sysFileCVFSMgr, vfsFtrIDVersion, &value) == 0 && value != 0;
#ifdef btLibFeatureCreator
  features->bluetooth = FtrGet(btLibFeatureCreator, btLibFeatureVersion, &value) == 0 && value != 0;
#endif
  features->hddisplay = FtrGet(sysFtrCreator, sysFtrNumWinVersion, &value) == 0 && value >= 4;
  features->sound_stream = FtrGet(sysFileCSoundMgr, sndFtrIDVersion, &value) == 0 && value > 0;
  { 
    SonySysFtrSysInfoP sonySysFtrSysInfoP;
    features->sony_hr = FtrGet(sonySysFtrCreator, sonySysFtrNumSysInfoP, (UInt32*)&sonySysFtrSysInfoP) == 0
      && (sonySysFtrSysInfoP->libr & sonySysFtrSysInfoLibrHR) != 0;
  }
  features->handera = (FtrGet(TRGSysFtrID, TRGVgaFtrNum, &value) == 0) && (sysGetROMVerMajor(value) >= 1);
  if (features->hddisplay) {
    /* hdd feature set is present, is the screen double density? */
    UInt32 attr;
    features->is_dd_display = WinScreenGetAttribute(winScreenDensity, &attr) == 0 && attr == kDensityDouble;
  }
}
