/*
** Doodle, a drawing program for palmtop computers running PalmOS.
**
** Doodle is Copyright (c) 1997, 2002 by Roger E Critchlow Jr,
** Santa Fe, New Mexico, USA, rec@elf.org.
**
** Portions of Doodle are derived from DiddleBug.  DiddleBug is
** Copyright (c) 2001 Peter Putzer <pputzer@users.sourceforge.net>
** Copyright (c) 1999,2000 Mitch Blevins <mblevin@debian.org>.
** 
** This file is part of Doodle.
**
** Doodle is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** Doodle is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with Doodle; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/* Application type identifier */
#ifndef AppType
#define AppType	0x7263444F	/* 'rcDO' */
#endif

/* Application version - decimal number of tenths */
#ifndef AppVersion
#define AppVersion 8
#endif

/* Database type */
#ifndef DBType
#define DBType	0x44617461	/* 'Data' */
#endif

/* Database name */
#ifndef DBName
#define DBName "DoodleDB"
#endif

/* Preferences version */
#ifndef PrefsVersion
#define PrefsVersion 100*AppVersion+13
#endif

/* Preferences ID */
#ifndef PrefsID
#define PrefsID 0

/* Number of pixels allowed in a pen */
#ifndef NPENPIX
#define NPENPIX	29
#endif

/* Number of pen events which may be weighted together */
#ifndef NPENWTS
#define NPENWTS 16		/* must be power of two */
#endif

/* Size of buffer for beam exchanges */
#define BEAM_BUF_SIZE 512

/*
** Operations.
**
** The characters define the operations which doodle performs,
** the menu shortcuts for the operations, the menu identifiers
** in the menus, and the control buttons in the title bar.
**
** The strings define the sequence taken when the control is
** tapped once.
**
** The last two commands do not appear in the menues, and their
** 'shortcuts' are only recognized with no command stroke.
*/

#define modePaint       'P'
#define modeErase       'E'
#define modeAdd         '+'
#define modeSub         '-'
#define modeSequence	"PE+-"

#define cmdRough        '<'
#define cmdSmooth       '='
#define cmdSmoother     '>'
#define smoothSequence  "<=>"

#define penFine         '.'
#define penMedium       '~'
#define penBold         '#'
#define penBroad        '@'
#define penFineItalic   ','
#define penMediumItalic '/'
#define penBroadItalic  ';'
#define penBroadUncial  '_'
#define penSequence     ".~#@,/;_"
#define penPick         '*'

#define inkWhite        '0'
#define inkDith12       '1'
#define inkDith25       '2'
#define inkDith37       '3'
#define inkDith50       '4'
#define inkDith62       '5'
#define inkDith75       '6'
#define inkDith87       '7'
#define inkBlack        '8'
#define inkRandom       '9'
#define inkShift        '$'
#define inkSequence     "012345678"
#define inkPick '&'

#define cmdClear        'C'
#define cmdFill         'F'
#define cmdRemove       'R'
#define cmdNew          'N'
#define cmdDuplicate    'D'
#define cmdBeam         'B'
#define cmdCopy         'W'
#define cmdPaste        'Y'

#define cmdTitle        'T'
#define cmdPreferences  'S'
#define cmdAbout        'A'
#define cmdHelp         'H'
#define cmdAltHelp      '?'

#define cmdPageUp       '\b'
#define cmdPageDown     ' '
#define cmdPageNew      '\n'

#define cmdPickAccept   'A'
#define cmdPickCancel   'C'

#endif

