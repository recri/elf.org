/*
** Doodle, a drawing program for palmtop computers running PalmOS.
**
** Doodle is Copyright (c) 1997, 2002 by Roger E Critchlow Jr,
** Santa Fe, New Mexico, USA, rec@elf.org.
**
** Portions of Doodle are derived from DiddleBug.  DiddleBug is
** Copyright (c) 2001 Peter Putzer <pputzer@users.sourceforge.net>
** Copyright (c) 1999,2000 Mitch Blevins <mblevin@debian.org>.
** 
** This file is part of Doodle.
**
** Doodle is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** Doodle is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with Doodle; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/*
** pre35.c - operations implemented using traps available in PalmOS 1.0
*/

#define ALLOW_ACCESS_TO_INTERNALS_OF_WINDOWS 1
#include <PalmOS.h>
WinHandle MakeWindowBitsPre35(Err *e) {
  return WinCreateOffscreenWindow(160, 160, genericFormat, e);
}
void FreeWindowBitsPre35(WinHandle w) {
  WinDeleteWindow(w, false);
}
void *GetWindowBitsPointerPre35(WinHandle w) {
  return WinGetWindowPointer(w)->displayAddrV20;
}
int GetWindowPixelPre35(void *bits, short x, short y) {
  return (((char *)bits)[y*160/8+x/8]&(0x80>>(x%8))) != 0;
}
	  
