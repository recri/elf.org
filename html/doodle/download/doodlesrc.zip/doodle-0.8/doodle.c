/*
** Doodle, a drawing program for palmtop computers running PalmOS.
**
** Doodle is Copyright (c) 1997, 2002 by Roger E Critchlow Jr,
** Santa Fe, New Mexico, USA, rec@elf.org.
**
** Portions of Doodle are derived from DiddleBug.  DiddleBug is
** Copyright (c) 2001 Peter Putzer <pputzer@users.sourceforge.net>
** Copyright (c) 1999,2000 Mitch Blevins <mblevin@debian.org>.
** 
** This file is part of Doodle.
**
** Doodle is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** Doodle is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with Doodle; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/*
** PalmOS includes
*/
#include <PalmOS.h>
#include <PalmOSGlue.h>
#include <Vga.h>                                        // HandEra 330
#undef vchrSonyMin
#undef vchrSonyMax
#include <SonyCLIE.h>                                   // Sony Clie

/*
** Doodle includes.
*/
#include "doodle.h"
#include "features.h"
#include "resource.h"

#define DEBUG_FIELD 0

/*
** External functions and macros for version switching
*/
extern WinHandle MakeWindowBitsPre35(Err *e);
extern WinHandle MakeWindowBitsPost35(Err *e);
extern void FreeWindowBitsPre35(WinHandle w);
extern void FreeWindowBitsPost35(WinHandle w);
extern void *GetWindowBitsPointerPre35(WinHandle w);
extern void *GetWindowBitsPointerPost35(WinHandle w);
extern int GetWindowPixelPre35(void *bits, short x, short y);
extern int GetWindowPixelPost35(void *bits, short x, short y);

#define MakeWindowBits(e) d.makeWindowBits(e)
#define FreeWindowBits(w) d.freeWindowBits(w)
#define GetWindowBitsPointer(w) d.getWindowBitsPointer(w)
#define GetWindowPixel(b,x,y) d.getWindowPixel(b,x,y)

/*
** Extract the pen pixel offsets from pen center
** out of the penpex array bytes.
** The x and y coordinates are limited to 0..15
** 8 is taken as the center coordinate.
*/
#define dxFromPenpix(p)	(((int)(p>>4)&0xF)-8)
#define dyFromPenpix(p)	(((int)(p&0xF))-8)


/*
** Standard penpixel set, now stored as resources.
** You may edit the resources to change the pen set,
** but you cannot have a 0 byte in a resource string
** because they are stored as NUL terminated strings.
*/

/*
** Default ink pattern set, now stored, other than White and Black,
** as resources. You may edit the resources to change the ink set,
** but you cannot have a 0 byte in a resource string because they
** are stored as NUL terminated strings.
*/
#define patternWhiteBytes	"\x00\x00\x00\x00\x00\x00\x00\x00"
#define patternBlackBytes	"\xff\xff\xff\xff\xff\xff\xff\xff"

/*
** Whole image rectangle.
*/
static const RectangleType wholeRect = { 0, 0, 160, 160 };

/*
** Below title bar rectangle.
*/
static const RectangleType partRect = { 0, 16, 160, 144 };

/*
** Structure for recording filter, pen, and ink preference
** for each drawing mode.
*/
typedef struct {
  char filt, pen, ink;                                  /* smooth, pen, and ink chars */
  UInt8 inkShiftCount;                                  /* ink shift index into PatternShiftString */
  UInt16 filter;                                        /* filter size */
  UInt8 penpix[NPENPIX+1];                              /* pen coordinate offsets */
  CustomPatternType inkpat;                             /* ink pattern */
} filtpenandink;
  
/*
** A Screen size V0 Bitmap for copy and paste.
*/
typedef struct {
  Int16 width;
  Int16 height;
  UInt16 rowBytes;
  UInt16 flags;                                         /* BitmapFlagsType */ 
  UInt16 reserved[4];
  UInt8 bytes[160][20];
} Bitmap;

/*
** Preferences structure.
*/
typedef struct {
  UInt16 version;                                       /* version number */
  Int16 dbI;                                            /* page record */
  UInt16 formID;                                        /* titled or untitled */
  RectangleType r;                                      /* current drawing window */
  char mode;                                            /* mode character */
  UInt8 prefSmoothFilter;                               /* log #points to filter in smooth */
  filtpenandink c;                                      /* current filter, pen, and ink */
  Int16 pickInkPage;                                    /* page last used to pick an ink */
  Int16 pickPenPage;                                    /* page last used to pick a pen */
  UInt32 prefFlags;                                     /* preference flags */
#define prefConfirmClear        0                       /* present a confirm dialog when clear */
#define prefConfirmFill         1                       /* present a confirm dialog when fill */
#define prefConfirmPaste        2                       /* present a confirm dialog when paste */
#define prefConfirmRemove       3                       /* present a confirm dialog when remove */
#define prefConfirmTitle        4                       /* present a confirm dialog when title off */
#define prefTitleOnStart        5                       /* restore the title bar on startup */
#define prefAlignedInk          6                       /* align ink pick to 8,8 boundaries */
#define prefMemoPickPage        7                       /* remember pick pages for later picks */

} pref;

/*
** Global data structure.
*/
typedef struct {
  DmOpenRef dbR;                                        /* database handle */
  WinHandle winM;                                       /* main window */
  WinHandle bufM;                                       /* Offscreen window with depth 1 */
  WinHandle penM;                                       /* Offscreen window with depth 1 */
  UInt16 formID;                                        /* titled or untitled */
  WinHandle (*makeWindowBits)();                        /* allocating off screen window */
  void (*freeWindowBits)(WinHandle bits);               /* freeing off screen window */
  void *(*getWindowBitsPointer)(WinHandle w);           /* finding window bits pointer */
  int (*getWindowPixel)(void *b, short x, short y);     /* getting a pixel from the bits */
  struct wts {
    UInt16 x, y;                                        /* incoming pen coordinates */
  } wts[NPENWTS];
  UInt16 nwts;                                          /* pen event coordinates */
  UInt16 wx, wy;                                        /* sum of pwt pen coordinates */
  UInt16 ox, oy;                                        /* last synthesized pen coordinates */
  UInt16 npixels;                                       /* size of pixel array */
  /* Hardware support */
  Features features;                                    /* features available bits */
  UInt16 sonyHRRefNum;                                  /* References number of Sony hi-res library */
  Boolean sonyLoadedHRLib;                              /* Did we load the hi-res library ourselves? */
  /* Miscellaneous stuff */
  char page_number[16];                                 /* Page number converted to ascii */
  filtpenandink savedfpi;                               /* saved filter, pen, and ink preference, for pick dialogs */
  Int16 saveddbI;                                       /* saved page for pick dialogs */
  RectangleType penR;                                   /* pen control rectangle */
  RectangleType inkR;                                   /* ink control rectangle */
  UInt16 cx, cy;                                        /* controlEnterEvent coordinates for swipe */
  Bitmap bitmap;                                        /* Bitmap for copy and paste */
  Char message[128];                                    /* Buffer for loading resource strings */
} data;

static data d;                                          /* initialized to zero */

static const pref defp = {                              /* default preferences */
  PrefsVersion,                                         /* preferences version */
  0,                                                    /* page record */
  DoodleTitleForm,                                      /* default form, with title */
  { 0, 18, 160, 142 },                                  /* default clipping rectangle */
  modePaint,                                            /* default mode */
  1,                                                    /* smooth filter */
  { cmdSmooth, penMedium, inkBlack, 0, 4,
    "",
    patternBlackBytes
  },
  -1,                                                   /* pick ink page */
  -1,                                                   /* pick pen page */
  0xffffffff                                            /* flags */
};

static pref p;                                          /* actual preferences */

#if 0
#define abort(msg)	ErrDisplayFileLineMsg(__FILE__, __LINE__, msg)
#else
#define abort(msg)	ErrDisplayFileLineMsg(__FILE__, __LINE__, "")
#endif

/*
** Test if a character is lower case.
** US Ascii version.
*/
static inline UInt16 ChrIsLower(WChar chr) { return chr >= 'a' && chr <= 'z'; }

/*
** Map a character to upper case.
** US Ascii version.
*/
static inline WChar ChrToUpper(WChar chr) { return chr - ('a'-'A'); }

/*
** Test if a preference flag bit is set.
*/
static inline UInt16 PrefIsSet(UInt16 prefBit) { return (p.prefFlags&(((UInt32)1)<<prefBit)) != 0; }

/*
** Test if any preference in a range is set.
*/
static inline UInt16 PrefIsAnySet(UInt16 firstPrefBit, UInt16 lastPrefBit)
{
  return (p.prefFlags&(((1<<(lastPrefBit+1))-1)&((1<<(firstPrefBit-1))-1))) != 0;
}

/*
** Clear a preference flag bit.
*/
static inline void PrefClear(UInt16 prefBit) { p.prefFlags &= ~(((UInt32)1)<<prefBit); }

/*
** Set a preference flag bit.
*/
static inline void PrefSet(UInt16 prefBit) { p.prefFlags |= (((UInt32)1)<<prefBit); }

/*
** Set a preference flag according to a value.
*/
static inline void PrefSetValue(UInt16 prefBit, UInt16 value) { if (value) PrefSet(prefBit); else PrefClear(prefBit); }

/*
** GetObjectPointer - return an object pointer given a form and objID
*/
static void* GetObjectPointer(FormPtr frm, UInt16 objID)
{
  return FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, objID));
}

/*
** SetLabel - set the label of a control on the current form.
*/
static inline void SetLabel(Int16 objectID, char *label)
{
  CtlSetLabel(GetObjectPointer(FrmGetActiveForm(), objectID), label);
}

/*
** SetValue - set the value of a control on the specified form
*/
static void SetValue(FormPtr frm, Int16 objectId, Int16 value)
{
  CtlSetValue(GetObjectPointer(frm, objectId), value);
}

/*
** GetValue - get the value of a control on the specified form
*/
static Int16 GetValue(FormPtr frm, Int16 objectId)
{
  return CtlGetValue(GetObjectPointer(frm, objectId));
}

/*
** PushWindow - push the window drawing state.
*/
static WinHandle PushWindow(WinHandle newH)
{
  WinHandle oldH = WinSetDrawWindow(newH);

  if (d.features.palmos_3_5) {
    WinPushDrawState();
    WinSetBackColor(0);
    // WinSetForeColor(1);
  }

  /* Reset screen mode for Handera 330 */
  /* ??? but what if I'm not drawing to screen ??? */
  if (d.features.handera) VgaSetScreenMode(screenMode1To1, rotateModeNone);

  return oldH;
}

/*
** PopWindow - pop the window drawing state.
*/
static void PopWindow(WinHandle oldH)
{

  if (d.features.palmos_3_5) WinPopDrawState();

  /* Restore screen mode for Handera 330 */
  /* ??? but I'm not drawing to screen ??? */
  if (d.features.handera) VgaSetScreenMode(screenModeScaleToFit, rotateModeNone);

  WinSetDrawWindow(oldH);
}

static void LabelGraphicButton(UInt16 ctlID, UInt16 chr)
{
  FormType *frm = FrmGetActiveForm();
  Coord x, y;
  MemHandle t;
  FrmGetObjectPosition(frm, FrmGetObjectIndex(frm, ctlID), &x, &y);
  t = DmGetResource(bitmapRsc, BaseBmp+chr);
  WinDrawBitmap((BitmapType *)MemHandleLock(t), x, y);
  MemHandleUnlock(t);
  DmReleaseResource(t);
}

/*
** LabelMode - put the mode label in the title bar.
*/
static inline void LabelMode(void)
{
  if (FrmGetActiveFormID() == DoodleTitleForm)
    LabelGraphicButton(ModeCtl, p.mode);
}

/*
** LabelFilter - put the filter label in the title bar.
*/
static inline void LabelFilter(void)
{
  if (FrmGetActiveFormID() == DoodleTitleForm)
    LabelGraphicButton(SmoothCtl, p.c.filt);
}

/*
** LabelPen - put the pen label in the title bar.
*/
static void LabelPen(void)
{
  switch (FrmGetActiveFormID()) {
  case DoodleTitleForm:
  case PickPenForm:
    {
      UInt8 *pix;
      Int16 x, y;
      WinHandle oldH;
    
      /* Draw current pen */
      oldH = PushWindow(d.penM);

      /* Current pen */
      WinEraseRectangle(&d.penR, 0);
      WinSetPattern((const CustomPatternType *)patternBlackBytes);
      for (pix = p.c.penpix; *pix != 0; pix += 1) {
        x = d.penR.topLeft.x+d.penR.extent.x/2-1+dxFromPenpix(*pix);
        y = d.penR.topLeft.y+d.penR.extent.y/2+dyFromPenpix(*pix);
        WinFillLine(x, y, x, y);
      }

      /* Copy pen to form */
      WinCopyRectangle(d.penM, d.winM, &d.penR, d.penR.topLeft.x, d.penR.topLeft.y, winPaint);
      
      /* Restore draw state */
      PopWindow(oldH);
    }
  }
}

/*
** LabelInk - put the ink label in the title bar.
*/
static void LabelInk(void)
{
  switch (FrmGetActiveFormID()) {
  case DoodleTitleForm:
  case PickInkForm:
    {
      WinHandle oldH = PushWindow(d.penM);

      /* Current ink */
      WinEraseRectangle(&d.inkR, 0);
      WinSetPattern((const CustomPatternType*)&p.c.inkpat);
      WinFillRectangle(&d.inkR, 0);
      /* Now outline the inkwell */
      {
        int x0 = d.inkR.topLeft.x;
        int y0 = d.inkR.topLeft.y;
        int x1 = d.inkR.topLeft.x+d.inkR.extent.x-1;
        int y1 = d.inkR.topLeft.y+d.inkR.extent.y-1;
        WinDrawLine(x0, y0, x1, y0);
        WinDrawLine(x1, y0, x1, y1);
        WinDrawLine(x1, y1, x0, y1);
        WinDrawLine(x0, y1, x0, y0);
      }

      /* Copy ink to form */
      WinCopyRectangle(d.penM, d.winM, &d.inkR, d.inkR.topLeft.x, d.inkR.topLeft.y, winPaint);
      
      /* Restore draw state */
      PopWindow(oldH);
    }
  }
}

/*
** LabelPage - put the page label in the title bar.
*/
static inline void LabelPage(void)
{
  switch (FrmGetActiveFormID()) {
  case DoodleTitleForm:
  case PickInkForm:
  case PickPenForm:
    StrIToA(d.page_number, p.dbI+1);
    SetLabel(PageCtl, d.page_number);
  }
}

/*
** LabelImage - put the program state in the title bar
*/
static void LabelImage(void)
{
  if (FrmGetActiveFormID() != DoodleForm) {
    LabelMode();
    LabelFilter();
    LabelPen();
    LabelInk();
    LabelPage();
  }
}

/*
** AllocImage - create a new image record.
*/
static void AllocImage(void)
{
  MemHandle t;
  t = DmNewRecord(d.dbR, &p.dbI, 3200);
  if ( ! t) abort("AllocImage failed to New");
  DmReleaseRecord(d.dbR, p.dbI, true);
}

/*
** ClearImage - clear a new image record.
*/
static inline void ClearImage(void)
{
  MemHandle t;
  t = DmGetRecord(d.dbR, p.dbI);
  if ( ! t) abort("ClearImage failed to Get");
  DmSet(MemHandleLock(t), 0, 3200, 0);
  MemHandleUnlock(t);
  DmReleaseRecord(d.dbR, p.dbI, true);
}

/*
** MakeImage - allocate and clear a new image record.
*/
static void MakeImage(void)
{
  AllocImage();
  ClearImage();
}

/*
** LoadImage - copy the database record p.dbI onto the current display buffer.
*/
static void LoadImage(void)
{
  MemHandle t;
  UInt16 error;
  t = DmQueryRecord(d.dbR, p.dbI);
  if ( ! t) {
    MakeImage();
    t = DmQueryRecord(d.dbR, p.dbI);
    if (! t) abort("LoadImage failed to load");
  }
  MemMove(GetWindowBitsPointer(d.bufM), MemHandleLock(t), 3200);
  MemHandleUnlock(t);
}

/*
** SaveImage - copy the current display into the database record p.dbI.
*/
static void SaveImage(void)
{
  MemHandle t;
  t = DmGetRecord(d.dbR, p.dbI);
  if ( ! t) abort("SaveImage failed to Get");
  DmWrite(MemHandleLock(t), 0, GetWindowBitsPointer(d.bufM), 3200);
  MemHandleUnlock(t);
  DmReleaseRecord(d.dbR, p.dbI, true);
}

/*
** DisplayImageRect - copy the current display image to the handheld display window
*/
static void DisplayImageRect(RectangleType *rp)
{
  WinHandle oldH = PushWindow(d.winM);
  WinCopyRectangle(d.bufM, d.winM, rp, rp->topLeft.x, rp->topLeft.y, winPaint);
  PopWindow(oldH);
}

static inline void DisplayWholeImage() {
  DisplayImageRect((RectangleType *)&wholeRect);
}

static inline void DisplayPartImage() {
  DisplayImageRect((RectangleType *)&partRect);
}
/*
** DisplayImage - copy the appropriate part of the current display image to the handheld
** display window, used in Title On/Of
*/
static void DisplayImage() {
  if (p.formID == DoodleForm)
    DisplayWholeImage();
  else
    DisplayPartImage();
}

/*
** GotoImage - jump to the specified image.
*/
static void GotoImage(Int16 i) {
  if (i != p.dbI) {
    SaveImage();
    p.dbI = i;
    LoadImage();
  }
}

/*
** Advance to next image.
*/
static void NextImage(void)
{
  GotoImage((p.dbI+1) % DmNumRecords(d.dbR));
}

/*
** Retreat to previous page.
*/
static void PreviousImage(void)
{
  int n = DmNumRecords(d.dbR);
  GotoImage((p.dbI+n-1) % n);
}

/*
** Random integer in the range 0..(n-1).
*/
static inline UInt16 RandomLessThan(UInt16 n) { return SysRandom(0) / (1+sysRandomMax/n); }

/*
** SendGotoEvent
** from diddlebug
*/
static inline void SendGotoEvent(UInt16 recordNum)
{
  EventType event;
  event.eType = frmGotoEvent;
  event.data.frmGoto.formID = p.formID;
  event.data.frmGoto.recordNum = recordNum;
  EvtAddEventToQueue(&event);
}

/*
** BeamSend
** from diddlebug
*/
static inline void BeamSend(void)
{
  ExgSocketType exgSock;
  MemHandle t;
  MemPtr ptr;
  UInt16 pos, bytes_to_send, bytes_sent;
  UInt16 recSize;
  UInt8 buf[BEAM_BUF_SIZE];
  Char tempString[32];
  UInt8 tempSize;
  Err err;

  /* Zero the exchange socket */
  MemSet(&exgSock, sizeof(ExgSocketType), 0);

  /* Set the target */
  exgSock.target = AppType;

  /* Set the name and description */
  SysCopyStringResource(tempString, BeamContentString);
  tempSize = StrLen(tempString) + 1;
  exgSock.name = MemPtrNew(tempSize);
  StrNCopy(exgSock.name, tempString, tempSize);
  SysCopyStringResource(tempString, BeamTypeString);
  tempSize = StrLen(tempString) + 1;
  exgSock.description = MemPtrNew(tempSize);
  StrNCopy(exgSock.description, tempString, tempSize);

  /* Open the record */
  t = DmQueryRecord(d.dbR, p.dbI);
  ptr = MemHandleLock(t);

  /* Set the length */
  recSize = 3200;
  exgSock.length = recSize;

  /* Do the beaming */
  err = ExgPut(&exgSock);
  if (!err) {
    pos = 0;
    while (1) {
      bytes_to_send = (((recSize-pos) < BEAM_BUF_SIZE) ? (recSize-pos) : BEAM_BUF_SIZE);
      if (!bytes_to_send) break;
      MemMove(buf, ptr+pos, bytes_to_send);
      bytes_sent = ExgSend(&exgSock, buf, bytes_to_send, &err);
      if (err) break;
      pos += bytes_sent;
    }
    ExgDisconnect(&exgSock, err);
  }

  /* Cleanup */
  MemHandleUnlock(t);
  MemPtrFree(exgSock.name);
  MemPtrFree(exgSock.description);
}

/*
** BeamReceive - i before e, except after c
** from diddlebug
*/
static inline void BeamReceive(ExgSocketPtr sockP, Boolean appIsActive)
{
  DmOpenRef dbR;
  UInt16 recIndex, recSize;
  UInt16 pos = 0, bytes_got;
  UInt8 buf[BEAM_BUF_SIZE];
  MemHandle t;
  MemPtr ptr;
  Err err = 0;

  /* Open the database */
  if (appIsActive)
    dbR = d.dbR;
  else {
    dbR = DmOpenDatabaseByTypeCreator(DBType, AppType, dmModeReadWrite|dmModeShowSecret);
    if (!dbR) return;
  }

  /* Create the new record */
  recIndex = dmMaxRecordIndex;
  recSize = BEAM_BUF_SIZE;
  t = DmNewRecord(dbR, &recIndex, recSize);
  if (t) {
    ptr = MemHandleLock(t);
    DmSet(ptr, 0, recSize, 0);
    /* Open Socket and start receiving */
    err = ExgAccept(sockP);

    if (!err) {
      pos = 0;
      while (true) {
        bytes_got = ExgReceive(sockP, buf, BEAM_BUF_SIZE, &err);
        if (!bytes_got) break;
        if (err) break;
        DmWrite(ptr, pos, buf, bytes_got);
        pos += bytes_got;
        MemHandleUnlock(t);
        recSize = pos+BEAM_BUF_SIZE;
        t = DmResizeRecord(dbR, recIndex, recSize);
        ptr = MemHandleLock(t);
      }

      ExgDisconnect(sockP, err);
    }

    MemHandleUnlock(t);
    t = DmResizeRecord(dbR, recIndex, pos);
    DmReleaseRecord(dbR, recIndex, true);
  }

  if (err) {
    DmRemoveRecord(dbR, recIndex);
  } else {
    /* Jump to the record */
    UInt16 cardNo;
    LocalID dbID;

    DmOpenDatabaseInfo(dbR, &dbID, NULL, NULL, &cardNo, NULL);
    sockP->goToCreator = AppType;
    sockP->goToParams.dbCardNo = cardNo;
    sockP->goToParams.dbID = dbID;
    sockP->goToParams.recordNum = recIndex;
  }

  /* Close the database */
  if (!appIsActive) DmCloseDatabase(dbR);
}

/*
** Confirm an operation with optional string parameter.
*/
static inline UInt16 ConfirmOperation(UInt16 prefBit, UInt16 confirmForm)
{
  if ( ! PrefIsSet(prefBit)) return 1;                  /* confirm is off */
  switch (FrmAlert(confirmForm)) {
  case 0: return 1;                                     /* go ahead */
  case 1: PrefClear(prefBit); return 1;                 /* go ahead, and shut up already */
  case 2: return 0;                                     /* don't do it */
  }
}

/*
** Confirm various operations.
*/
static inline UInt16 ConfirmClear(void) { return ConfirmOperation(prefConfirmClear, ConfirmClearForm); }
static inline UInt16 ConfirmFill(void) { return ConfirmOperation(prefConfirmFill, ConfirmFillForm); }
static inline UInt16 ConfirmPaste(void) { return ConfirmOperation(prefConfirmPaste, ConfirmPasteForm); }
static inline UInt16 ConfirmRemove(void) { return ConfirmOperation(prefConfirmRemove, ConfirmRemoveForm); }
static inline UInt16 ConfirmTitle(void) { return ConfirmOperation(prefConfirmTitle, ConfirmTitleForm); }

/*
** Turn the title bar on or off.
*/
static inline void TitlePage()
{
  if (p.formID == DoodleTitleForm) {
    if (ConfirmTitle())
      FrmGotoForm(DoodleForm);
  } else
      FrmGotoForm(DoodleTitleForm);
}
    
/*
** Clear the current page.
*/
static inline void ClearPage()
{
  if (ConfirmClear()) {
    WinHandle oldH = PushWindow(d.bufM);
    WinEraseRectangle(&wholeRect, 0);
    PopWindow(oldH);
    /* at this point the current image is clear in d.bufM but not in database */
  }
}

/*
** Fill the current page.
*/
static inline void FillPage()
{
  if (ConfirmFill()) {
    UInt16 winMode =
      p.mode == modeSub ? winMask :
      p.mode == modeAdd ? winOverlay :
      p.mode == modeErase ? winInvert : winPaint;
    if (d.features.palmos_3_5) {
      WinHandle oldH = PushWindow(d.bufM);
      WinSetPattern((const CustomPatternType *)&p.c.inkpat);
      WinSetDrawMode(winMode);
      WinPaintRectangle(&wholeRect, 0);
      PopWindow(oldH);
    } else {
      WinHandle oldH = PushWindow(d.penM);
      WinEraseRectangle(&wholeRect, 0);
      WinSetPattern((const CustomPatternType *)&p.c.inkpat);
      WinFillRectangle(&wholeRect, 0);
      WinCopyRectangle(d.penM, d.bufM, &wholeRect, wholeRect.topLeft.x, wholeRect.topLeft.y, winMode);
      PopWindow(oldH);
    }
  }
}

/*
** Create a new page after the current page.
*/
static inline void NewPage()
{
  p.dbI += 1;
  MakeImage();
  LoadImage();
}

/*
** Duplicate the current page.
*/
static inline void DuplicatePage()
{
  p.dbI += 1;
  AllocImage();
  SaveImage();
  LoadImage();
}

/*
** Remove the current page.
*/
static inline void RemovePage()
{
  if (ConfirmRemove()) {
    DmRemoveRecord(d.dbR, p.dbI);
    if (p.dbI > 0)
      p.dbI -= 1;
    else if (p.dbI == DmNumRecords(d.dbR))
      MakeImage();
    LoadImage();
  }
}

/*
** Copy the current page to an offscreen buffer.
** (Try for the clipboard eventually.
*/
static inline void CopyPage()
{
#if 0
  d.bitmap.width = 160;
  d.bitmap.height = 160;
  d.bitmap.rowBytes = 20;
#endif
  MemMove(&d.bitmap.bytes[0][0], GetWindowBitsPointer(d.bufM), sizeof(d.bitmap.bytes));
}

/*
** Paste the offscreen copy buffer into the current page.
*/
static inline void PastePage()
{
  if (ConfirmPaste()) {
    UInt32 *dstp = GetWindowBitsPointer(d.bufM);
    UInt32 *srcp = (UInt32 *)&d.bitmap.bytes[0][0];
    Int16 nbyte = sizeof(d.bitmap.bytes)/4;
    switch (p.mode) {
    case modePaint: while (--nbyte >= 0) *dstp++ =   *srcp++; break;
    case modeAdd:   while (--nbyte >= 0) *dstp++ |=  *srcp++; break;
    case modeSub:   while (--nbyte >= 0) *dstp++ &= ~*srcp++; break;
    case modeErase: while (--nbyte >= 0) *dstp++ ^=  *srcp++; break;
    }
  }
}

/*
** Load a pen pattern
*/
static void LoadPen(Int16 chr, const Int8 *pen)
{
  StrCopy(p.c.penpix, pen);
  p.c.pen = chr;
}

/*
** Load a pen from a resource.
*/
static inline void LoadPenResource(Int16 chr)
{
  char pen[NPENPIX+1];
  SysCopyStringResource(pen, PenString+chr);
  LoadPen(chr, pen);
}

/*
** Load an ink pattern
*/
static void LoadInk(Int16 chr, const CustomPatternType *pattern)
{
  if (pattern != NULL) {
    /* Load the specified ink pattern */
    p.c.ink = chr;
    p.c.inkShiftCount = 0;
    MemMove(p.c.inkpat, pattern, sizeof(p.c.inkpat));
  } else if (chr == inkRandom) {
    /* Shuffle the existing pattern to make a new pattern */
    unsigned i, id, im, ib, j, jd, jm, jb;

    SysRandom(((long *)p.c.inkpat)[0]+((long *)p.c.inkpat)[1]);
    for (i = 0; i < 64; i += 1) {
      j = i + RandomLessThan(64-i);
      ib = p.c.inkpat[id = i/8] & (im = 1<<(i%8));
      jb = p.c.inkpat[jd = j/8] & (jm = 1<<(j%8));
      if (ib)
        p.c.inkpat[jd] |= jm;
      else
        p.c.inkpat[jd] &= ~jm;
      if (jb)
        p.c.inkpat[id] |= im;
      else
        p.c.inkpat[id] &= ~im;
    }
  } else if (chr == inkShift) {
    UInt8 shift[66];
    UInt8 pix;
    Int16 dx, dy;

    SysCopyStringResource(shift, PatternString+chr);
    pix = shift[p.c.inkShiftCount%StrLen(shift)];
    dx = dxFromPenpix(pix);
    dy = dyFromPenpix(pix);
    if (dx > 0) {
      while (--dx >= 0) {
        /* Shift the current pattern one pixel to the right */
        int i;
        for (i = 0; i < 8; i += 1)
          p.c.inkpat[i] = ((p.c.inkpat[i]>>1)&0x7f)|((p.c.inkpat[i]<<7)&0x80);
      }
    } else if (dx < 0) {
      while (++dx <= 0) {
        /* Shift the current pattern one pixel to the left */
        int i;
        for (i = 0; i < 8; i += 1)
          p.c.inkpat[i] = ((p.c.inkpat[i]&0x7f)<<1)|((p.c.inkpat[i]&0x80)>>7);
      }
    }
    if (dy > 0) {
      while (--dy >= 0) {
        /* Shift the current pattern one pixel downwards */
        UInt8 t = p.c.inkpat[7];
        int i;
        p.c.inkpat[7] = p.c.inkpat[6];
        p.c.inkpat[6] = p.c.inkpat[5];
        p.c.inkpat[5] = p.c.inkpat[4];
        p.c.inkpat[4] = p.c.inkpat[3];
        p.c.inkpat[3] = p.c.inkpat[2];
        p.c.inkpat[2] = p.c.inkpat[1];
        p.c.inkpat[1] = p.c.inkpat[0];
        p.c.inkpat[0] = t;
      }
    } else if (dy < 0) {
      while (++dy <= 0) {
        /* Shift the current pattern one pixel upwards */
        UInt8 t = p.c.inkpat[0];
        p.c.inkpat[0] = p.c.inkpat[1];
        p.c.inkpat[1] = p.c.inkpat[2];
        p.c.inkpat[2] = p.c.inkpat[3];
        p.c.inkpat[3] = p.c.inkpat[4];
        p.c.inkpat[4] = p.c.inkpat[5];
        p.c.inkpat[5] = p.c.inkpat[6];
        p.c.inkpat[6] = p.c.inkpat[7];
        p.c.inkpat[7] = t;
      }
    }
    p.c.inkShiftCount += 1;
  }
}

/*
** Load an ink from a resource.
*/
static inline void LoadInkResource(Int16 chr)
{
  char ink[sizeof(CustomPatternType)+1];
  SysCopyStringResource(ink, PatternString+chr);
  LoadInk(chr, (const CustomPatternType *)ink);
}

/*
** Load a new filter specification.
*/
static inline void LoadFilter(UInt16 chr, UInt16 filter)
{
  p.c.filt = chr;
  p.c.filter = filter;
}

/*
** Load the current mode.
*/
static inline void LoadMode(UInt16 chr)
{
  p.mode = chr;
}

/*
** Set up for a pen/ink pick dialog.
*/
static void GotoPickForm(UInt16 prefMemoPage, Int16 memoPage, Int16 formID)
{
  SaveImage();
  d.savedfpi = p.c;
  d.saveddbI = p.dbI;
  if (prefMemoPage && memoPage != -1)
    GotoImage(memoPage);
  FrmGotoForm(formID);
}

/*
** Act on a key (or translated menu event) received.
*/
static Boolean DoodleKeyDown(WChar chr)
{
  EventType event;
  event.eType = keyDownEvent;
  event.data.keyDown.chr = chr;
  event.data.keyDown.keyCode = 0;
  event.data.keyDown.modifiers = 0;
  EvtAddEventToQueue(&event);
}

/*
** Swipe codes.
*/
#define SWIPE_NIL	-1
#define SWIPE_N		0
#define SWIPE_NE	1
#define SWIPE_E		2
#define SWIPE_SE	3
#define SWIPE_S		4
#define SWIPE_SW	5
#define SWIPE_W		6
#define SWIPE_NW	7

/*
** Reduce a pair of coordinates to a swipe code and
** its distance swiped squared.
*/
static Int16 QuantizeSwipe(Int16 x0, Int16 y0, Int16 x1, Int16 y1, Int16 *dist2)
{
  Int16 dx = x1-x0;
  Int16 dy = y1-y0;
  *dist2 = dx*dx + dy*dy;
  if (dx == 0)
    return dy > 0 ? SWIPE_S : dy < 0 ? SWIPE_N : SWIPE_NIL;
  if (dy == 0)
    return dx > 0 ? SWIPE_E : SWIPE_W;
  {
    Int16 dxpdy = 10*dx/dy;
    Int16 dypdx = 10*dy/dx;

    if (dx > 0) {               /* dx > 0 -> E */
      if (dy > 0) {             /* dy > 0 -> S */
        if (dxpdy > 24)         return SWIPE_E;
        if (dypdx > 24)         return SWIPE_S;
        return SWIPE_SE;
      } else {                  /* dy < 0 -> N */
        if (dxpdy < -24)        return SWIPE_E;
        if (dypdx < -24)        return SWIPE_N;
        return SWIPE_NE;
      }
    } else {                    /* dx < 0 -> W */
      if (dy > 0) {             /* dy > 0 -> S */
        if (dxpdy < -24)        return SWIPE_W;
        if (dypdx < -24)        return SWIPE_S;
        return SWIPE_SW;
      } else  {                 /* dy < 0 -> N */
        if (dxpdy > 24)         return SWIPE_W;
        if (dypdx > 24)         return SWIPE_N;
        return SWIPE_NW;
      }
    }
  }
  abort("QuantizeSwipe fell through?");
}    

/*
** Follow a swipe out of a control and classify it.
*/
static Int16 FollowSwipe(Int16 sx, Int16 sy, Int16 ix, Int16 iy)
{
  Boolean penDown;
  Int16 nx, ny, dir0, dist20, dir1, dist21;
  do {
    EvtGetPen(&nx, &ny, &penDown);
  } while (penDown && RctPtInRectangle(nx, ny, &wholeRect));
  /* A swipe is a swipe if the direction (sx,sy -> ix,iy) and
   * the direction (sx,sy -> nx,ny) both quantize to the same
   * octant, and the length (sx,sy -> ix,iy) is less than half
   * the length (sx,sy -> nx,ny).
   */
  dir0 = QuantizeSwipe(sx, sy, ix, iy, &dist20);
  dir1 = QuantizeSwipe(sx, sy, nx, ny, &dist21);
  // return (dir0 == dir1 && dist20*4 < dist21) ? dir0 : SWIPE_NIL;
  return (dir0 == dir1) ? dir0 : SWIPE_NIL;
  return dir1;
}

/*
** Enumerate the codes passed by FollowStylus to its handler function.
*/
typedef enum {
  selector_start, selector_continue, selector_finish
} selectorCode;

/*
** Clamp a coordinate to a range
*/
static Int16 ClampCoord(Int16 c, Int16 cmin, Int16 cmax)
{
  return c < cmin ? cmin : c > cmax ? cmax : c;
}

/*
** Invert a frame around a rectangle.
*/
static void InvertRectangle(int x, int y, int width, int height)
{
  RectangleType r1, r2;
  RctSetRectangle(&r1, x, y, width, height);
  RctGetIntersection(&r1, &p.r, &r2);
  WinInvertRectangleFrame(simpleFrame, &r2);
}

/*
** FollowStylus handler function for pen selection.
*/
static void PenSelector(selectorCode code, Int16 x, Int16 y, Int16 ox, Int16 oy)
{
  /* adjust coordinates to upper left corner */
  x -= 7;
  y -= 4;
  ox -= 7;
  oy -= 4;
  /* clamp the coordinates so the selected box is in the window */
  x = ClampCoord(x, 0, 160-14);
  y = ClampCoord(y, 0, 160-7);
  ox = ClampCoord(ox, 0, 160-14);
  oy = ClampCoord(oy, 0, 160-7);

  switch (code) {
  case selector_start:
    InvertRectangle(x, y, 14, 7);
    break;
  case selector_continue:
    InvertRectangle(ox, oy, 14, 7);
    InvertRectangle(x, y, 14, 7);
    {
      /*
      ** Scan a 14x7 pixel array around the selected point.
      ** Going out in distance from the selected point
      ** accumulate penpixel coordinates until the maximum
      ** allowed has been gathered.  Install the penpixels as the pen.
      ** Note that the penpixel is a nul terminated string.
      */
      /* The new pen */
      UInt8 pen[NPENPIX+1];
      /* The penpixels sorted from the center out */
      UInt8 *pix =	
        "\x88\x78\x87\x89\x98\x77\x79\x97\x99\x68\x86\x8a\xa8\x67"
        "\x69\x76\x7a\x96\x9a\xa7\xa9\x66\x6a\xa6\xaa\x58\x85\x8b"
        "\xb8\x57\x59\x75\x7b\x95\x9b\xb7\xb9\x56\x5a\x65\x6b\xa5"
        "\xab\xb6\xba\x48\xc8\x47\x49\xc7\xc9\x55\x5b\xb5\xbb\x46"
        "\x4a\xc6\xca\x38\x45\x4b\xc5\xcb\xd8\x37\x39\xd7\xd9\x36"
        "\x3a\xd6\xda\x35\x3b\xd5\xdb\x28\xe8\x27\x29\xe7\xe9\x26"
        "\x2a\xe6\xea\x25\x2b\xe5\xeb\x18\x17\x19\x16\x1a\x15\x1b";
      void *bits = GetWindowBitsPointer(d.bufM);
      int i;
      /* copy penpixels working from the center out */
      for (i = 0; *pix != 0 && i < NPENPIX; pix += 1) {
        int nx = x+7+dxFromPenpix(*pix);
        int ny = y+4+dyFromPenpix(*pix);
        if (ny >= 160) continue;
        if (GetWindowPixel(bits, nx, ny))
          pen[i++] = *pix;
      }
      pen[i] = 0;
      // if (i > NPENPIX) abort("Scanned too many penpix");
      /* load the new ink, keep the ink character for sequencing */
      LoadPen(p.c.pen, pen);
      /* update the title bar */
      LabelPen();
    }
    break;
  case selector_finish:
    InvertRectangle(ox, oy, 14, 7);
    break;
  }
}

/*
** FollowStylus handler function for ink selection
*/
static void InkSelector(selectorCode code, Int16 x, Int16 y, Int16 ox, Int16 oy)
{
  /* adjust coordinates to upper left corner */
  x -= 4;
  y -= 4;
  ox -= 4;
  oy -= 4;
  /* clamp the coordinates so the selected box is in the window */
  x = ClampCoord(x, 0, 160-8);
  y = ClampCoord(y, 0, 160-8);
  ox = ClampCoord(ox, 0, 160-8);
  oy = ClampCoord(oy, 0, 160-8);
  /* if aligned ink then clamp to 8x8 boundaries */
  if (PrefIsSet(prefAlignedInk)) {
    x &= ~7;
    y &= ~7;
    ox &= ~7;
    oy &= ~7;
  }
  switch (code) {
  case selector_start:
    InvertRectangle(x, y, 8, 8);
    break;
  case selector_continue:
    InvertRectangle(ox, oy, 8, 8);
    InvertRectangle(x, y, 8, 8);
    {
      /*
      ** scan an 8x8 pixel array around the selected point and build a
      ** custom pattern.  Install the custom pattern as the ink.
      */
      CustomPatternType ink;
      UInt8 *ptr;
      int i, j;
      /* pointer to 0, 0 in d.bufM */
      ptr = GetWindowBitsPointer(d.bufM);
      /* copy 8 bytes into ink */
      for (i = 0; i < 8; i += 1) {
        int ny = y+i;
        ink[i] = 0;
        for (j = 0; j < 8; j += 1) {
          int nx = x+j;
          ink[i] <<= 1;
          ink[i] |= GetWindowPixel(ptr, nx, ny);
        }
      }
      /* load the new ink, keep the ink character for sequencing */
      LoadInk(p.c.ink, (const CustomPatternType *)&ink);
      /* update the title bar */
      LabelInk();
    }
    break;
  case selector_finish:
    InvertRectangle(ox, oy, 8, 8);
    break;
  }
}

/*
** Follow the stylus as it exits a title bar control until the
** pen is lifted or it leaves the drawing area.  Pass successive
** pen positions to the handler function.
*/
static inline Boolean FollowStylus(void (*handler)(selectorCode, Int16, Int16, Int16, Int16), Int16 ox, Int16 oy)
{
  Boolean penDown;
  Int16 x = ox, y = oy;

  handler(selector_start, x, y, ox, oy);

  do {
    ox = x;
    oy = y;
    EvtGetPen(&x, &y, &penDown);
    handler(selector_continue, x, y, ox, oy);
  } while (penDown);

  handler(selector_finish, x, y, ox, oy);
  return true;
}

static Boolean PickEvent(EventPtr e, void (*handler)(selectorCode, Int16, Int16, Int16, Int16), Int16 *memoDbI, Int16 helpString)
{
  if (!WinGetDrawWindow())
    WinSetDrawWindow(WinGetDisplayWindow());
  switch (e->eType) {
  case frmUpdateEvent:
    FrmDrawForm(FrmGetActiveForm());
  ShowImage:
    LabelImage();
    DisplayPartImage();
    return true;
  case frmOpenEvent:
    d.winM = FrmGetWindowHandle(FrmGetActiveForm());
    p.r = partRect;
    LoadImage();
    FrmDrawForm(FrmGetActiveForm());
    goto ShowImage;
  case appStopEvent:
    p.c = d.savedfpi;
    SaveImage();
    p.dbI = d.saveddbI;
    break;
  case frmCloseEvent:
    break;
  case penDownEvent:
    if ( ! RctPtInRectangle(e->screenX, e->screenY, &p.r))
      return false;
    FollowStylus(handler, e->screenX, e->screenY);
    return true;
  case ctlEnterEvent:
    d.cx = e->screenX;
    d.cy = e->screenY;
    break;
  case ctlExitEvent:
    switch (FollowSwipe(d.cx, d.cy, e->screenX, e->screenY)) {
    case SWIPE_W:
      switch (e->data.ctlExit.controlID) {
      case PenCtl:              /* fall through */
      case InkCtl:              goto cancel;       
      case PageCtl:             goto previous;
      }
      break;
    case SWIPE_E:
      switch (e->data.ctlExit.controlID) {
      case PenCtl:              /* fall through */
      case InkCtl:              goto okay;
      case PageCtl:             goto next;
      }
      break;
    }
    break;
  case ctlSelectEvent:
    switch (e->data.ctlEnter.controlID) {
    case PenCtl:                /* fall through */
    case InkCtl:                goto okay;
    case PageCtl:               goto next;
    case HelpCtl:               goto help;
    }
    break;
  case menuEvent:
    switch (e->data.menu.itemID) {
    case MenuItemAcceptPick:    goto okay;
    case MenuItemCancelPick:    goto cancel;
    case MenuItemHelpPick:      goto help;
    }
    break;
  case keyDownEvent:
    {
      WChar chr = e->data.keyDown.chr;
      chr = ChrIsLower(chr) ? ChrToUpper(chr) : chr;
      switch (chr) {
      case cmdPickAccept:       /* fall through */
      okay:                     *memoDbI = p.dbI; GotoImage(d.saveddbI); FrmGotoForm(p.formID); return true;
      case cmdPickCancel:       /* fall through */
      cancel:                   p.c = d.savedfpi; GotoImage(d.saveddbI); FrmGotoForm(p.formID); return true;
      case cmdPageUp:           /* fall through */
      case pageUpChr:           /* fall through */
      previous:                 PreviousImage(); goto ShowImage;
      case cmdPageDown:         /* fall through */
      case pageDownChr:         /* fall through */
      next:                     NextImage(); goto ShowImage;
      case cmdAltHelp:          /* fall through */
      case cmdHelp:             /* fall through */
      help:                     FrmHelp(helpString); return true;
      }
      break;
    }

  }
  return false;
}

/*
** Ink selector event handler.
*/
static Boolean PickInkEvent(EventPtr e)
{
  return PickEvent(e, InkSelector, &p.pickInkPage, PickInkHelpString);
}

/*
** Pen selector event handler.
*/
static Boolean PickPenEvent(EventPtr e)
{
  return PickEvent(e, PenSelector, &p.pickPenPage, PickPenHelpString);
}

/*
** Clear the pen state.
*/
static void DoodlePenClear(void)
{
  d.nwts = d.wx = d.wy = 0;
  MemSet(d.wts, sizeof(d.wts), 0);
}

/*
** Act on a doodle pen event.
*/
static void DoodlePenEvent(eventsEnum etype, Int16 nx, Int16 ny)
{
  if (etype != penDownEvent) {
    Int8 *pix;
    Int16 dx, dy, lx, rx, ty, by, x1, y1, x2, y2;
    RectangleType r;
    WinHandle oldH;

    /* Save old draw window and state */
    if (p.mode == modePaint || p.mode == modeErase) {
      /* paint and erase mode draw directly to offscreen image */
      oldH = PushWindow(d.bufM);
    } else {
      /* add and subtract draw mask to offscreen mask buffer */
      oldH = PushWindow(d.penM);
      /* Clear the buffer */
      WinEraseRectangle(&wholeRect, 0);
    }

    /* Set the ink pattern */
    WinSetPattern((const CustomPatternType *)&p.c.inkpat);

    /* Initialize bounding rectangle */
    rx = lx = d.ox;
    ty = by = d.oy;

    /* Draw the lines defined by the pen */
    for (pix = p.c.penpix; *pix != 0; pix += 1) {
      dx = dxFromPenpix(*pix);
      dy = dyFromPenpix(*pix);
      x1 = d.ox + dx;
      y1 = d.oy + dy;
      x2 = nx + dx;
      y2 = ny + dy;
      if ((unsigned)x1 >= 160 || (unsigned)y1 >= 160 || (unsigned)x2 >= 160 || (unsigned)y2 >= 160)
        continue;
      if (p.mode == modeErase)
        WinEraseLine(x1, y1, x2, y2);
      else
        WinFillLine(x1, y1, x2, y2);

      /* Update bounding rectangle */
      if (x1 < x2) {
        lx = lx < x1 ? lx : x1;
        rx = rx > x2 ? rx : x2;
      } else {
        lx = lx < x2 ? lx : x2;
        rx = rx > x1 ? rx : x1;
      }
      if (y1 < y2) {
        ty = ty < y1 ? ty : y1;
        by = by > y2 ? by : y2;
      } else {
        ty = ty < y2 ? ty : y2;
        by = by > y1 ? by : y1;
      }
    }

    /* Construct the bounding rectangle */
    RctSetRectangle(&r, lx, ty, rx - lx + 1, by - ty + 1);
    
    /* Combine the stroke with the image */
    if (p.mode == modeSub) {
      /* winMask is dst &= ~src which erases the set pixels in the patterned stroke */
      WinCopyRectangle(d.penM, d.bufM, &r, r.topLeft.x, r.topLeft.y, winMask);
    } else if (p.mode == modeAdd) {
      WinCopyRectangle(d.penM, d.bufM, &r, r.topLeft.x, r.topLeft.y, winOverlay);
    }

    /* Mirror the display onto the screen */
    {
      RectangleType s;
      RctGetIntersection(&r, &p.r, &s);
      DisplayImageRect(&s);
    }

    /* Restore drawing state */
    PopWindow(oldH);
  }
  d.ox = nx;
  d.oy = ny;
}

/*
** Choose the successor to the current choice on some menu.
*/
static unsigned int ChooseSuccessor(int now, unsigned char *choices)
{
  unsigned char *cp = StrChr(choices, now);
  return (cp == NULL || cp[1] == 0) ? choices[0] : cp[1];
}

/*
** Choose the predecessor to the current choice on some menu.
*/
static unsigned int ChoosePredecessor(int now, unsigned char *choices)
{
  unsigned char *cp = StrChr(choices, now);
  return (cp == NULL || cp == choices) ? choices[StrLen(choices)-1] : cp[-1];
}

/*
** DoodleEvent - handle events on the doodling form.
** Adapted from DiddleBug 2.52
*/
static Boolean DoodleEvent(EventPtr e)
{
  Boolean handled = false;

  /*
  ** The debug ROM's complain if we don't set this first.
  */
  if (!WinGetDrawWindow()) WinSetDrawWindow(WinGetDisplayWindow());

  switch (e->eType) {

  case frmUpdateEvent:
    FrmDrawForm(FrmGetActiveForm());
  ShowImage:
    LabelImage();
    DisplayImage();
    handled = true;
    break;

  case frmOpenEvent:
    d.winM = FrmGetWindowHandle(FrmGetActiveForm());
    if (p.formID == DoodleForm)
      p.r = wholeRect;
    else
      p.r = partRect;
    LoadImage();
    FrmDrawForm(FrmGetActiveForm());
    DoodleKeyDown(p.mode);
    DoodleKeyDown(p.c.filt);
    LoadPen(p.c.pen, p.c.penpix);
    LoadInk(p.c.ink, (const CustomPatternType *)p.c.inkpat);
    goto ShowImage;

  case winEnterEvent:
    break;

  case winExitEvent:
    SaveImage();
    break;

  case appStopEvent:
  case frmCloseEvent:
    SaveImage();
    break;

  case frmGotoEvent:
    GotoImage(e->data.frmGoto.recordNum);
    goto ShowImage;

  case menuOpenEvent:
    if (d.features.palmos_3_0) {
      MenuAddItem(MenuItemTitle, MenuItemBeam, cmdBeam, "Beam");
    }
    break;

  case menuEvent:       handled = DoodleKeyDown(e->data.menu.itemID-DoodleMenu); break;

  case keyDownEvent:
    {
      /* Map command character to upper case */
      WChar chr = ChrIsLower(e->data.keyDown.chr) ? ChrToUpper(e->data.keyDown.chr) : e->data.keyDown.chr;

      /* Dispatch on character */
      switch (chr) {
      
      case modePaint:
      case modeErase:
      case modeSub:
      case modeAdd:         LoadMode(chr); break;

      case cmdRough:        LoadFilter(chr, 1); break;
      case cmdSmooth:       LoadFilter(chr, 1<<p.prefSmoothFilter); break;
      case cmdSmoother:     LoadFilter(chr, 1<<(1+p.prefSmoothFilter)); break;

      case penFine:
      case penMedium:
      case penBold:
      case penBroad:
      case penFineItalic:
      case penMediumItalic:
      case penBroadItalic:
      case penBroadUncial:  LoadPenResource(chr); break;
      case penPick:         GotoPickForm(PrefIsSet(prefMemoPickPage), p.pickPenPage, PickPenForm); break;

      case inkWhite:        LoadInk(chr, (const CustomPatternType *)patternWhiteBytes); break;
      case inkDith12:
      case inkDith25:
      case inkDith37:
      case inkDith50:
      case inkDith62:
      case inkDith75:
      case inkDith87:       LoadInkResource(chr); break;
      case inkBlack:        LoadInk(chr, (const CustomPatternType *)patternBlackBytes); break;
      case inkShift:
      case inkRandom:       LoadInk(chr, NULL); break;
      case inkPick:         GotoPickForm(PrefIsSet(prefMemoPickPage), p.pickInkPage, PickInkForm); break;

      case cmdPreferences:  FrmGotoForm(PrefForm); break;
      case cmdAbout:        FrmAlert(AboutDoodleForm); break;
      case cmdAltHelp:      /* fall through */
      case cmdHelp:         FrmHelp(DoodleHelpString); break;

      case cmdTitle:        SaveImage(); TitlePage(); break;

      case cmdClear:        SaveImage(); ClearPage(); break;
      case cmdFill:         SaveImage(); FillPage(); break;
      case cmdPageNew:
      case cmdNew:          SaveImage(); NewPage(); break;
      case cmdDuplicate:    SaveImage(); DuplicatePage(); break;
      case cmdRemove:       SaveImage(); RemovePage(); break;
      case cmdCopy:         SaveImage(); CopyPage(); break;
      case cmdPaste:        SaveImage(); PastePage(); break;

      case cmdBeam:         SaveImage(); BeamSend(); break;
    
      case cmdPageUp:
      case pageUpChr:       PreviousImage(); break;

      case cmdPageDown:
      case pageDownChr:     NextImage(); break;
      }

      LabelImage();
      DisplayImage();
      handled = true;
      break;
    }

  case ctlEnterEvent:
    d.cx = e->screenX;
    d.cy = e->screenY;
    break;

  case ctlExitEvent:
    switch (FollowSwipe(d.cx, d.cy, e->screenX, e->screenY)) {
    case SWIPE_W:
      switch (e->data.ctlExit.controlID) {
      case ModeCtl:     DoodleKeyDown(ChoosePredecessor(p.mode, modeSequence)); break;
      case SmoothCtl:   DoodleKeyDown(ChoosePredecessor(p.c.filt, smoothSequence)); break;
      case PenCtl:      DoodleKeyDown(ChoosePredecessor(p.c.pen, penSequence)); break;
      case InkCtl:      DoodleKeyDown(ChoosePredecessor(p.c.ink, inkSequence)); break;
      case PageCtl:     DoodleKeyDown(cmdPageUp); break;
      }
      break;
    case SWIPE_E:
      switch (e->data.ctlExit.controlID) {
      case ModeCtl:     DoodleKeyDown(ChooseSuccessor(p.mode, modeSequence)); break;
      case SmoothCtl:   DoodleKeyDown(ChooseSuccessor(p.c.filt, smoothSequence)); break;
      case PenCtl:      DoodleKeyDown(ChooseSuccessor(p.c.pen, penSequence)); break;
      case InkCtl:      DoodleKeyDown(ChooseSuccessor(p.c.ink, inkSequence)); break;
      case PageCtl:     DoodleKeyDown(cmdPageDown); break;
      }
      break;
    case SWIPE_S:
      switch (e->data.ctlExit.controlID) {
      case PenCtl:      DoodleKeyDown(penPick); break;
      case InkCtl:      DoodleKeyDown(inkPick); break;
      }
      break;
    }
    break;

  case ctlSelectEvent:
    switch (e->data.ctlEnter.controlID) {
    case ModeCtl:       handled = DoodleKeyDown(ChooseSuccessor(p.mode, modeSequence)); break;
    case SmoothCtl:     handled = DoodleKeyDown(ChooseSuccessor(p.c.filt, smoothSequence)); break;
    case PenCtl:        handled = DoodleKeyDown(ChooseSuccessor(p.c.pen, penSequence)); break;
    case InkCtl:        handled = DoodleKeyDown(ChooseSuccessor(p.c.ink, inkSequence)); break;
    case PageCtl:       handled = DoodleKeyDown(cmdPageDown); break;
    case HelpCtl:       handled = DoodleKeyDown(cmdHelp); break;
    }
    break;

  case penDownEvent:
    /* Clear pen state */
    DoodlePenClear();
    /* fall through */

  case penMoveEvent:
  case penUpEvent:
    {
      Boolean in_bounds = RctPtInRectangle(e->screenX, e->screenY, &p.r);
      unsigned short i, n;

      if (in_bounds) {
        /* Update sum of coordinates */
        n = (d.nwts-p.c.filter)%NPENWTS;
        d.wx += e->screenX - d.wts[n].x;
        d.wy += e->screenY - d.wts[n].y;

        /* Update array of coordinates */
        n = d.nwts%NPENWTS;
        d.wts[n].x = e->screenX;
        d.wts[n].y = e->screenY;

        /* Send averaged coordinate */
        n = (d.nwts >= p.c.filter) ? p.c.filter : d.nwts+1;
        DoodlePenEvent(d.nwts ? e->eType : penDownEvent, d.wx/n, d.wy/n);

        /* Update count of coordinates */
        d.nwts += 1;
      }

      /* Pen up or out of bounds ends the stroke */
      if (e->eType == penUpEvent || ! in_bounds) {
        /* Drain queue */
        short i;
        for (i = (d.nwts < p.c.filter) ? d.nwts : p.c.filter; --i > 0; ) {
          n = (d.nwts-i-1)%NPENWTS;
          d.wx -= d.wts[n].x;
          d.wy -= d.wts[n].y;
          DoodlePenEvent(penMoveEvent, d.wx/i, d.wy/i);
        }
        /* Clear state */
        DoodlePenClear();
      }

      /* leave out of bounds events unhandled */
      handled = in_bounds;
      break;
    }
  }

  return handled;
}

/*
** PrefEvent - handle events on the Preferences form
*/
Boolean PrefEvent(EventPtr e)
{
  Boolean handled = false;
  FormPtr frm;
  ListPtr list;
  int i;

  switch (e->eType) {

  case frmOpenEvent:		/* Set values of controls according to preferences */
    frm = FrmGetActiveForm();
    for (i = prefConfirmClear; i < prefMemoPickPage-prefConfirmClear+1; i += 1)
      SetValue(frm, PrefConfirmClear+i, PrefIsSet(prefConfirmClear+i));
    list = GetObjectPointer(frm, PrefSmoothingList);
    LstSetSelection(list, p.prefSmoothFilter-1);
    SetLabel(PrefSmoothingPop, LstGetSelectionText(list, p.prefSmoothFilter-1));
    FrmDrawForm(frm);
    handled = true;
    break;

  case ctlSelectEvent:
    switch (e->data.ctlEnter.controlID) {
    case PrefOKButton:		/* Load preferences from form data */
      frm = FrmGetActiveForm();
      for (i = prefConfirmClear; i < prefMemoPickPage-prefConfirmClear+1; i += 1)
        PrefSetValue(prefConfirmClear+i, GetValue(frm, PrefConfirmClear+i));
      list = GetObjectPointer(frm, PrefSmoothingList);
      p.prefSmoothFilter = LstGetSelection(list)+1;
      DoodleKeyDown(p.c.filt);		/* to reset filter weight */
      FrmGotoForm(p.formID);
      handled = true;
      break;
    case PrefCancelButton:
      FrmGotoForm(p.formID);
      handled = true;
      break;
    }
    break;

  default:
    // do nothing
  }

  return handled;
}

/*
** Set up hi-res mode for Sony Clies
**
** Also stores the refNum of the HR library.
** Taken from DiddleBug 2.52
*/
static inline void SetUpSony(UInt16* refNum, Boolean* loadedHRLib)
{
  Err error = 0;

  if ((error = SysLibFind(sonySysLibNameHR, refNum))) {
    if (error == sysErrLibNotFound) {
      /* couldn't find lib */
      error = SysLibLoad('libr', sonySysFileCHRLib, refNum);
      *loadedHRLib = true;
    }
  }
  if (!error) {
    /* Now we can use HR lib */
    UInt32 width = hrWidth;
    UInt32 height = hrHeight;

    /* Set compatibility mode */
    HROpen(*refNum);
    HRWinScreenMode(*refNum, winScreenModeSet, &width, &height, NULL, NULL);
    HRClose(*refNum);
  }
}

/*
** Test for ROM versions.
** Adapted from DiddleBug 2.52
*/
static inline void RomVersions(void)
{
  TestFeatures(&d.features);
  /* Figure out how to make, find, and free the bitmap bits */
  if (d.features.palmos_3_5) {
    d.makeWindowBits = MakeWindowBitsPost35;
    d.freeWindowBits = FreeWindowBitsPost35;
    d.getWindowBitsPointer = GetWindowBitsPointerPost35;
    d.getWindowPixel = GetWindowPixelPost35;
  } else {
    d.makeWindowBits = MakeWindowBitsPre35;
    d.freeWindowBits = FreeWindowBitsPre35;
    d.getWindowBitsPointer = GetWindowBitsPointerPre35;
    d.getWindowPixel = GetWindowPixelPre35;
  }
  /* Check for Sony and enable hi-res mode */
  if (d.features.sony_hr)
    SetUpSony(&d.sonyHRRefNum, &d.sonyLoadedHRLib);
}

/*
** Retrieve preferences (and initialize if no or wrong preferences were found)
** Return true on error
** Adapted from DiddleBug 2.52
*/
static Boolean GetMyPreferences(pref* prefs, Int16* oldVersion)
{
  if ( ! d.features.palmos_2_0) {
    if ( ! PrefGetAppPreferencesV10(AppType, PrefsVersion, prefs, sizeof(pref))) {
      *oldVersion = noPreferenceFound;
    } else if (prefs->version != PrefsVersion) {
      *oldVersion = prefs->version;
    } else {
      PrefGetAppPreferencesV10(AppType, PrefsVersion, prefs, sizeof(prefs));
      return false;
    }
  } else {
    Int16 version;
    UInt16 size = sizeof(pref);
    version = PrefGetAppPreferences(AppType, PrefsID, prefs, &size, true);
    if (version == noPreferenceFound || size != sizeof(pref) || prefs->version != PrefsVersion) {
      /* Save old version */
      if (version != noPreferenceFound)
        *oldVersion = prefs->version;
      else
        *oldVersion = noPreferenceFound;
    } else {
      /* everything OK */
      return false;
    }
  }
  /* Set up defaults */
  *prefs = defp;
  /* Load penpix definitions from resource file */
  SysCopyStringResource(prefs->c.penpix, PenString+prefs->c.pen);
  return true;
}

/*
** Retrieve preferences (and initialize if no or wrong preferences were found)
** Return true on error
*/
static inline void SetMyPreferences(pref *prefs)
{
  if ( ! d.features.palmos_2_0) {
    PrefSetAppPreferencesV10(AppType, PrefsVersion, prefs, sizeof(pref));
  } else {
    PrefSetAppPreferences(AppType, PrefsID, PrefsVersion, &p, sizeof(p), true);
  }
}
  
/*
** Start the application.
*/
static Err StartApplication()
{
  Err err;
  UInt16 oldVersion;
  LocalID dbID;
  UInt16 cardNo;
  UInt16 dbAttrs;

  /* Check for ROM versions */
  RomVersions();

  /* Create the offscreen buffer */
  err = 0;
  d.bufM = MakeWindowBits(&err);
  d.penM = MakeWindowBits(&err);
  if (err) {
    abort("Offscreen bitmap creation failed");
    return err;
  }
    
  /*
  ** Start application.
  ** Open database,
  ** fetch preferences,
  ** keep default preferences if version doesn't match.
  */
  if ((d.dbR = DmOpenDatabaseByTypeCreator(DBType, AppType, dmModeReadWrite)) != NULL) {
    if (GetMyPreferences(&p, &oldVersion)) {
      /* Upgrade records format for doodle-0.6? */
      if (!oldVersion == noPreferenceFound) {
        /* fix old versions */
      }
    }
  } else {
    GetMyPreferences(&p, &oldVersion);
    if (err = DmCreateDatabase(0, DBName, AppType, DBType, false)) {
      abort("Database creation failed");
      return err;
    }
    d.dbR = DmOpenDatabaseByTypeCreator(DBType, AppType, dmModeReadWrite);
  }

  /*
  ** Set the backup flag in the attributes so this database will be backed up.
  ** This adds 136 bytes to the program image.
  */
  if ((err = DmOpenDatabaseInfo(d.dbR, &dbID, NULL, NULL, &cardNo, NULL))
      || (err = DmDatabaseInfo(0, dbID, NULL, &dbAttrs, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL))) {
    DmCloseDatabase(d.dbR);
    abort("Database info retrieve failed");
    return err;
  }
  dbAttrs = dbAttrs | dmHdrAttrBackup;
  if (err = DmSetDatabaseInfo(0, dbID, NULL, &dbAttrs, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)) {
    DmCloseDatabase(d.dbR);
    abort("Database attribute setting failed");
    return err;
  }

  /*
  ** Restore the title bar if that's the preference
  */
  if (PrefIsSet(prefTitleOnStart))
    p.formID = DoodleTitleForm;

  /*
  ** Launch the current form.
  */
  if (DmQueryRecord(d.dbR, p.dbI) == NULL) {
    p.dbI = 0;			/* goto the first image */
  }
  FrmGotoForm(p.formID);

  /*
  ** return no error
  */
  return err;
}

/*
** Process application events.
*/
static void EventLoop()
{
  EventType e;
  UInt16 error;

  /*
  ** Process events.
  */
  do {
    FormPtr frm;
    UInt16 formID;

    EvtGetEvent(&e, evtWaitForever);

    if (SysHandleEvent(&e)) continue;

    if (MenuHandleEvent(NULL, &e, &error)) continue;

    if (e.eType == frmLoadEvent) {
      frm = FrmGetActiveForm();
      if (frm != NULL) {
        FrmEraseForm(frm);
        FrmDeleteForm(frm);
      }
      frm = FrmInitForm(e.data.frmLoad.formID);
      FrmSetActiveForm(frm);
      switch (e.data.frmLoad.formID) {
      case DoodleTitleForm:     FrmGetObjectBounds(frm, FrmGetObjectIndex(frm, PenCtl), &d.penR);
                                FrmGetObjectBounds(frm, FrmGetObjectIndex(frm, InkCtl), &d.inkR);
                                /* fall through */
      case DoodleForm:          p.formID = e.data.frmLoad.formID;
                                FrmSetEventHandler(frm, DoodleEvent); break;
      case PrefForm:            FrmSetEventHandler(frm, PrefEvent); break;
      case PickInkForm:         FrmGetObjectBounds(frm, FrmGetObjectIndex(frm, InkCtl), &d.inkR);
                                FrmSetEventHandler(frm, PickInkEvent); break;
      case PickPenForm:         FrmGetObjectBounds(frm, FrmGetObjectIndex(frm, PenCtl), &d.penR);
                                FrmSetEventHandler(frm, PickPenEvent); break;
      }
      continue;
    }

    FrmDispatchEvent(&e);

  } while (e.eType != appStopEvent);

}

/*
** Stop the application.
*/
static void StopApplication()
{
  /*
  ** Close all forms.
  */
  FrmCloseAllForms();

  /*
  ** Save preferences, and close database.
  */
  SetMyPreferences(&p);
  DmCloseDatabase(d.dbR);

  /*
  ** Free buffer bitmap and window
  */
  FreeWindowBits(d.bufM);
  FreeWindowBits(d.penM);

  /*
  ** Clean up HR library we're running on a Sony
  */
  if (d.features.sony_hr && d.sonyLoadedHRLib)
    SysLibRemove(d.sonyHRRefNum);

}

/*
** PilotMain - handle the toplevel command and event dispatch.
*/
UInt32 PilotMain(UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
  Err err;

  switch (cmd) {
    // case sysAppLaunchCmdNormalLaunch: // normal command start
    // case scptLaunchCmdExecuteCmd: // network plugin execute script
    // case scptLaunchCmdListCmds: // network plugin list commands
    // case sysAppLaunchCmdAddRecord: // add a mail record to the inbox
    // case sysAppLaunchCmdAlarmTriggered: // sound alarm or schedule next alarm, not allowed to block
    // case sysAppLaunchCmdAttention: // respond to the AttentionManager code
    // case sysAppLaunchCmdCardLaunch: // launching from expansion card
    // case sysAppLaunchCmdCountryChange: // country changed
    // case sysAppLaunchCmdDisplayAlarm: // respond to alarm, allowed to block
    // case sysAppLaunchCmdExgAskUser: // decide whether to accept beamed data
    // case sysAppLaunchCmdExgGetData: // remote client wants data, provide it
    // case sysAppLaunchCmdExgPreview: // preview incoming data
    // case sysAppLaunchCmdExgReceiveData: // receive incoming data
    // case sysAppLaunchCmdFind: // implement global find
    // case sysAppLaunchCmdGoto: // goto record from find or ExgReceiveData
    // case sysAppLaunchCmdGoToURL: // fetch URL
    // case sysAppLaunchCmdHandleSyncCallApp: // handle request from desktop
    // case sysAppLaunchCmdInitDatabase: // create database request from desktop
    // case sysAppLaunchCmdLookup: // as find, but look harder
    // case sysAppLaunchCmdNotify: // receive a broadcast notification
    // case sysAppLaunchCmdOpenDB: // web clipping query
    // case sysAppLaunchCmdPanelCalledFromApp: // call into system preferences panel
    // case sysAppLaunchCmdReturnFromPanel: // return from system preferences panel
    // case sysAppLaunchCmdSaveData: // save all data, eg before global find
    // case sysAppLaunchCmdSyncNotify: // your data changed during hotsync
    // case sysAppLaunchCmdSystemLock: // lock the palm, sent to security appl
    // case sysAppLaunchCmdSystemReset: // notification of system reset
    // case sysAppLaunchCmdTimeChange: // time changed
    // case sysAppLaunchCmdURLParams: // appl is launched/called to process URL

  case sysAppLaunchCmdNormalLaunch:
    if (err = StartApplication()) return err;
    EventLoop();
    StopApplication();
    break;

  case sysAppLaunchCmdGoTo:
    if (launchFlags&sysAppLaunchFlagNewGlobals) {
      if ((err = StartApplication())) return err;
      if ((((GoToParamsPtr)cmdPBP)->recordNum >= 0)
          || (((GoToParamsPtr)cmdPBP)->recordNum < DmNumRecords(d.dbR))) {
        p.dbI = ((GoToParamsPtr)cmdPBP)->recordNum;
        EventLoop();
      }
      StopApplication();
    } else {
      SendGotoEvent(((GoToParamsPtr) cmdPBP)->recordNum);
    }
    break;

  case sysAppLaunchCmdExgReceiveData:
    BeamReceive((ExgSocketPtr)cmdPBP, (launchFlags&sysAppLaunchFlagSubCall) != 0);
    break;
  }
  
  return 0;
}
