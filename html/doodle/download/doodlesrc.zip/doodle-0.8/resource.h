/*
** Doodle, a drawing program for palmtop computers running PalmOS.
**
** Doodle is Copyright (c) 1997, 2002 by Roger E Critchlow Jr,
** Santa Fe, New Mexico, USA, rec@elf.org.
**
** Portions of Doodle are derived from DiddleBug.  DiddleBug is
** Copyright (c) 2001 Peter Putzer <pputzer@users.sourceforge.net>
** Copyright (c) 1999,2000 Mitch Blevins <mblevin@debian.org>.
** 
** This file is part of Doodle.
**
** Doodle is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** Doodle is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with Doodle; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/*
** Resource identifiers.
** Why do I feel like I'm writing a program in BASIC?
*/

#define BaseBmp                 0

#define UnsmoothBmp             60      /* BaseBmp+'<' */
#define SmoothBmp               61      /* BaseBmp+'=' */
#define SmootherBmp             62      /* BaseBmp+'>' */

#define PaintBmp                80      /* BaseBmp+'P' */
#define EraseBmp                69      /* BaseBmp+'E' */
#define AddBmp                  43      /* BaseBmp+'+' */
#define SubBmp                  45      /* BaseBmp+'-' */

#define PenString               500
#define PenFineString           546     /* PenString+'.' */
#define PenMediumString         626     /* PenString+'~' */
#define PenBoldString           535     /* PenString+'#' */
#define PenBroadString          564     /* PenString+'@' */
#define PenFineItalicString     544     /* PenString+',' */
#define PenMediumItalicString   547     /* PenString+'/' */
#define PenBroadItalicString    559     /* PenString+';' */
#define PenBroadUncial          595     /* PenString+'_' */

#define PatternString           700
#define PatternWhiteString      748     /* PatternString+'0' */
#define PatternDith12String     749     /* PatternString+'1' */
#define PatternDith25String     750     /* PatternString+'2' */
#define PatternDith37String     751     /* PatternString+'3' */
#define PatternDith50String     752     /* PatternString+'4' */
#define PatternDith62String     753     /* PatternString+'5' */
#define PatternDith75String     754     /* PatternString+'6' */
#define PatternDith87String     755     /* PatternString+'7' */
#define PatternBlackString      756     /* PatternString+'8' */
#define PatternShiftString      736     /* PatternString+'$' */

#define DoodleForm                      1000
#define DoodleTitleForm                 1100
#define PickInkForm                     1200
#define PickInkHelpString               1201
#define PickPenForm                     1300
#define PickPenHelpString               1301
#define DoodleHelpString                1400
#define AboutDoodleForm                 1500
#define AboutDoodleHelpString           1501
#define ConfirmClearForm                1600
#define ConfirmClearHelpString          1601
#define ConfirmFillForm                 1610
#define ConfirmFillHelpString           1611
#define ConfirmPasteForm                1620
#define ConfirmPasteHelpString          1621
#define ConfirmRemoveForm               1630
#define ConfirmRemoveHelpString         1631
#define ConfirmTitleForm                1800
#define ConfirmTitleHelpString          1801

#define ModeCtl                 2100
#define SmoothCtl               2200
#define PenCtl                  2300
#define InkCtl                  2400
#define PageCtl                 2500
#define HelpCtl                 2600

#define DoodleMenu              3000
#define MenuSeparator           3257	/* DoodleMenu+257 */

#define MenuItemClear           3067	/* DoodleMenu+'C' */
#define MenuItemFill            3070	/* DoodleMenu+'F' */
#define MenuItemNew             3078	/* DoodleMenu+'N' */
#define	MenuItemDuplicate       3068    /* DoodleMenu+'D' */
#define MenuItemRemove          3082	/* DoodleMenu+'R' */
#define MenuItemBeam            3066	/* DoodleMenu+'B' */
#define MenuItemCopy            3087	/* DoodleMenu+'W' */
#define MenuItemPaste           3089	/* DoodleMenu+'Y' */
#define MenuItemTitle           3084	/* DoodleMenu+'T' */
#define MenuItemPrefs           3083	/* DoodleMenu+'S' */
#define MenuItemHelp            3072	/* DoodleMenu+'H' */
#define MenuItemAbout           3065	/* DoodleMenu+'A' */

#define MenuItemPaint           3080	/* DoodleMenu+'P' */
#define MenuItemErase           3069	/* DoodleMenu+'E' */
#define MenuItemAdd             3043	/* DoodleMenu+'+' */
#define MenuItemSub             3045	/* DoodleMenu+'-' */
#define MenuItemRough           3060    /* DoodleMenu+'<' */
#define MenuItemSmooth          3061	/* DoodleMenu+'=' */
#define MenuItemSmoother        3062    /* DoodleMenu+'>' */

#define MenuItemFine            3046	/* DoodleMenu+'.' */
#define MenuItemMedium          3126	/* DoodleMenu+'~' */
#define MenuItemBold            3035	/* DoodleMenu+'#' */
#define MenuItemBroad           3064	/* DoodleMenu+'@' */
#define MenuItemFItalic         3044	/* DoodleMenu+',' */
#define MenuItemMItalic         3047	/* DoodleMenu+'/' */
#define MenuItemBItalic         3059	/* DoodleMenu+';' */
#define MenuItemBUncial         3095	/* DoodleMenu+'_' */
#define MenuItemPickPen         3042	/* DoodleMenu+'*' */

#define MenuItemWhite           3048	/* DoodleMenu+'0' */
#define MenuItemDith12          3049	/* DoodleMenu+'1' */
#define MenuItemDith25          3050	/* DoodleMenu+'2' */
#define MenuItemDith37          3051	/* DoodleMenu+'3' */
#define MenuItemDith50          3052	/* DoodleMenu+'4' */
#define MenuItemDith62          3053	/* DoodleMenu+'5' */
#define MenuItemDith75          3054	/* DoodleMenu+'6' */
#define MenuItemDith87          3055	/* DoodleMenu+'7' */
#define MenuItemBlack           3056	/* DoodleMenu+'8' */
#define MenuItemShuffle         3057	/* DoodleMenu+'9' */
#define MenuItemShift           3036	/* DoodleMenu+'$' */
#define MenuItemPickInk         3038	/* DoodleMenu+'&' */

#define PickMenu                4000
#define MenuItemAcceptPick      4001
#define MenuItemCancelPick      4002
#define MenuItemHelpPick        4003

#define BeamContentString       7001
#define BeamTypeString          7002

#define PrefForm                8000
#define PrefHelpString                  8001
#define PrefOKButton                    8002
#define PrefCancelButton                8003

#define PrefConfirmClear                8010
#define PrefConfirmFill                 8011
#define PrefConfirmPaste                8012
#define PrefConfirmRemove               8013
#define PrefConfirmTitle                8014
#define PrefTitleOnStart                8015
#define PrefAlignedInk                  8016
#define PrefMemoPickPage                8017

#define PrefLightSmoothing              8050
#define PrefMediumSmoothing             8051
#define PrefHeavySmoothing              8052
#define PrefSmoothingGroup              8053
#define PrefSmoothingPop                8054
#define PrefSmoothingList               8055


#define GenericErrorAlert       8900
