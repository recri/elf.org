/*
** Doodle, a drawing program for palmtop computers running PalmOS.
**
** Doodle is Copyright (c) 1997, 2002 by Roger E Critchlow Jr,
** Santa Fe, New Mexico, USA, rec@elf.org.
**
** Portions of Doodle are derived from DiddleBug.  DiddleBug is
** Copyright (c) 2001 Peter Putzer <pputzer@users.sourceforge.net>
** Copyright (c) 1999,2000 Mitch Blevins <mblevin@debian.org>.
** 
** This file is part of Doodle.
**
** Doodle is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** Doodle is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with Doodle; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

typedef struct {
  UInt16 palmos_2_0:1;		/* system 2.0 */
  UInt16 palmos_3_0:1;		/* system 3.0 */
  UInt16 palmos_3_1:1;		/* system 3.1 */
  UInt16 palmos_3_2:1;		/* system 3.2 */
  UInt16 palmos_3_5:1;		/* system 3.5 */
  UInt16 palmos_4_0:1;		/* system 4.0 */
  UInt16 palmos_4_1:1;		/* system 4.1 */
  UInt16 palmos_5_0:1;		/* system 5.0 */
  UInt16 palmos_5_1:1;		/* system 5.1 */
  UInt16 international:1;	/* international feature set */
  UInt16 japanese:1;		/* japanese feature set */
  UInt16 serial_1:1;		/* new serial manager version 1 */
  UInt16 serial_2:1;		/* new serial manager version 2 */
  UInt16 connection:1;		/* connection manager */
  UInt16 notification:1;	/* notification */
  UInt16 expansion:1;		/* expansion manager */
  UInt16 vfs:1;			/* vfs file systems */
  UInt16 bluetooth:1;		/* bluetooth library */
  UInt16 hddisplay:1;		/* high density display */
  UInt16 sound_stream:1;	/* sound stream */
  UInt16 sony_hr:1;		/* sony high res display */
  UInt16 handera:1;		/* rotated drawing in bitmaps? */
  UInt16 is_dd_display:1;	/* is an actual double density display */
} Features;

extern void TestFeatures(Features *features);
